nnLearning) PS C:\Users\pjj18\Desktop\note\dl_basic\quant> python .\src\run_pipeline.py
============================================================
Pipeline: Lookback=20, Predict N=5
============================================================

[1/6] Loading data...
Loading stock info...
  2803 valid stocks after filtering
Loading daily data from 2019-01-01...
  Panel shape: (4755875, 9)

[2/6] Computing features + labels...
  Features: 20
  After dropna: 4685800 rows

[3/6] Creating dataloaders...
  Train: 4019601 rows, 1436 days
  Val:   666199 rows, 238 days
Train samples: 708000, Val samples: 610139

[4/6] Training LSTM...
Model params: 217,217
Device: cpu
C:\Users\pjj18\AppData\Roaming\Python\Python312\site-packages\torch\optim\lr_scheduler.py:62: UserWarning: The verbose parameter is deprecated. Please use get_last_lr() to access the learning rate.
  warnings.warn(
Epoch   1/50 | Train Loss: 0.330378 | Val Loss: 0.313498
  -> Best model saved (val_loss=0.313498)
Epoch   2/50 | Train Loss: 0.329252 | Val Loss: 0.312347
  -> Best model saved (val_loss=0.312347)
Epoch   3/50 | Train Loss: 0.328397 | Val Loss: 0.313605
Epoch   4/50 | Train Loss: 0.327759 | Val Loss: 0.312838
Epoch   5/50 | Train Loss: 0.327148 | Val Loss: 0.312347
  -> Best model saved (val_loss=0.312347)
Epoch   6/50 | Train Loss: 0.326550 | Val Loss: 0.312997
Epoch   7/50 | Train Loss: 0.325973 | Val Loss: 0.312420
Epoch   8/50 | Train Loss: 0.325478 | Val Loss: 0.313296
Epoch   9/50 | Train Loss: 0.324301 | Val Loss: 0.313043
Epoch  10/50 | Train Loss: 0.323594 | Val Loss: 0.313818
Epoch  11/50 | Train Loss: 0.323123 | Val Loss: 0.312767
Epoch  12/50 | Train Loss: 0.322522 | Val Loss: 0.314427
Epoch  13/50 | Train Loss: 0.321906 | Val Loss: 0.314405
Epoch  14/50 | Train Loss: 0.321312 | Val Loss: 0.315199
Epoch  15/50 | Train Loss: 0.319990 | Val Loss: 0.315695
Early stopping at epoch 15
Best epoch: 5, Best val loss: 0.312347

[5/6] Evaluating...
  Train metrics:
     IC Mean:        0.094279
     IC Std:         0.142101
     ICIR:           0.6635
     Direction Acc:  0.5626
     RMSE:           1.000275
     N Days:         1416
     N Samples:      708000

  Validation metrics:
     IC Mean:        0.065331
     IC Std:         0.121241
     ICIR:           0.5389
     Direction Acc:  0.5674
     RMSE:           1.004621
     N Days:         218
     N Samples:      610139

[6/6] Running backtest (validation period)...
Final Portfolio Value: 1,493,142.72
Annualized Return:     49.6542%
Sharpe Ratio:           2.0391
Max Drawdown:           -14.0025%
  Equal-weight benchmark return: 34.02%

============================================================
Pipeline complete.
============================================================
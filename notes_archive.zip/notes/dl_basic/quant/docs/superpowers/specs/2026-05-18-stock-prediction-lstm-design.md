# Stock Trend Prediction with LSTM — Design Spec

**Date:** 2026-05-18  
**Project:** 深度学习基础大作业 — 基于深度学习的股票趋势预测与模拟交易  
**Phase:** Phase 1 — LSTM Baseline

---

## 1. Overview

Predict future n-day stock returns using a 20-day lookback window of price/volume features. Build a simple daily rebalancing strategy (hold top-5, drop worst-1) and backtest against market benchmarks.

**Hard constraints:**
- No future information leakage
- Must include a deep learning (neural network) model
- Trading universe: all A-shares excluding ST, Beijing Exchange, and stocks listed <60 days
- Full position required during simulated trading (Jun 1–12, 2026)

---

## 2. Data Pipeline

### 2.1 Stock Filtering
- Exclude `market == '北交所'` from `basic.csv`
- Exclude any stock appearing in `stock_st/` (once ST → permanently excluded)
- Exclude stocks with `list_date` less than 60 trading days before the sample date

### 2.2 Time Series Construction
- Read all `daily/*.csv` files, aggregate per `ts_code` into individual time series
- Build `pandas.MultiIndex` (trade_date, ts_code) DataFrame
- Fields: open, high, low, close, pre_close, vol, amount, vwap, pct_chg

### 2.3 Missing Value Handling
- Suspension days: forward fill up to 5 days, keep NaN beyond
- First day after resumption: do not use filled values for feature calculation (or mark with flag)
- Remaining NaN: fill 0 for vol/amount, fill 0 for pct_chg

### 2.4 Feature Engineering

**Final feature list (20 dimensions):**

| # | Feature | Description |
|---|---|---|
| 1 | open | Raw opening price |
| 2 | high | Raw high price |
| 3 | low | Raw low price |
| 4 | close | Raw closing price |
| 5 | pre_close | Previous close (adjusted) |
| 6 | vol | Volume (lots) |
| 7 | amount | Turnover amount (thousand CNY) |
| 8 | vwap | Volume-weighted average price |
| 9 | pct_chg | Daily percentage change |
| 10 | ret_5d | 5-day cumulative return |
| 11 | ret_10d | 10-day cumulative return |
| 12 | ret_20d | 20-day cumulative return |
| 13 | vol_ma5 | 5-day moving average of volume |
| 14 | vol_ma20 | 20-day moving average of volume |
| 15 | turnover_rank | Daily cross-sectional volume rank (percentile 0–1) |
| 16 | amount_rank | Daily cross-sectional amount rank (percentile 0–1) |
| 17 | close_percentile | Daily cross-sectional close price percentile (0–1) |
| 18 | rsi_14 | Relative Strength Index (14-day) |
| 19 | macd | MACD line (12/26/9) |
| 20 | macd_signal | MACD signal line (9-day EMA of MACD) |

All raw price fields are normalized per-window (temporal Z-score). Cross-sectional rank features (15–17) provide relative position within the daily universe — these are strong signals against market-wide drift.

### 2.5 Label Construction
- Label at day t: n-day forward return = (close_{t+n} - close_t) / close_t
- Phase 1: primary n = 5 (5-day forward return), with n = 1 as comparison
- Cross-sectional Z-score normalization per trading day: (return - daily_mean) / daily_std
- This removes market-wide drift, isolates stock-specific signal
- This removes market-wide drift, isolates stock-specific signal

---

## 3. Sliding Window & Dataset

### 3.1 Window Construction
- Lookback: 20 trading days (configurable)
- For each stock on each trading day t: input = features from [t-19, t], shape = (20, n_features)
- Label = n-day forward return at day t (cross-sectional Z-scored)
- Mini-batch training: each batch contains samples from random stocks

### 3.2 Normalization (Leakage-Free)
- **Temporal (per-window):** For each (20, n_features) window, Z-score along time axis
- Implemented inside Dataset.__getitem__ before returning the sample
- No global statistics used — prevents look-ahead bias

### 3.3 PyTorch Dataset
- Returns `(X, y, ts_code, trade_date)` per sample
- DataLoader with `shuffle=False` (time-ordered iteration)
- Training: randomly sample 300–800 stocks per day (configurable, default 500)
- Validation/Backtest: use full universe (all stocks every day)

---

## 4. Model Architecture

### 4.1 Phase 1: LSTM Baseline

```
LSTM(
  input_dim: 20 (n_features)
  hidden_dim: 128
  num_layers: 2
  dropout: 0.2
  bidirectional: False
)
→ Take last hidden state
→ Linear(128, 64) → ReLU → Dropout(0.2)
→ Linear(64, 1)  # Scalar return prediction
```

**Training config:**
| Parameter | Value |
|---|---|
| Optimizer | Adam, lr=1e-3, weight_decay=1e-5 |
| Scheduler | ReduceLROnPlateau (patience=5, factor=0.5) |
| Batch size | 512 |
| Epochs | 50 (early stopping patience=10) |
| Loss | SmoothL1Loss (Huber) |
| Sampling | 500 stocks/day for training |

### 4.2 Phase 2 (Future): LSTM + Transformer
- LSTM encoder extracts temporal features → Transformer encoder captures cross-stock interactions
- Add pairwise ranking loss: Loss = SmoothL1 + λ * PairwiseRankingLoss (λ ≈ 0.1–1.0)

---

## 5. Evaluation

### 5.1 Model Metrics
| Metric | Description |
|---|---|
| MSE / RMSE | Prediction error on standardized returns |
| IC (Information Coefficient) | Daily cross-sectional corr(pred, true), averaged |
| ICIR | IC mean / IC std (measures stability) |
| Direction Accuracy | Fraction of samples where sign(pred) == sign(true) |

### 5.2 Backtest
- Vectorized backtest using pandas
- Initial capital: 1,000,000 CNY
- Day 1: equal-weight buy top-5 stocks by model score
- Each subsequent day: sell worst-1 from portfolio, buy best-1 from universe (exclude held)
- Constraints: T+1 (buy today → sellable tomorrow+), full position, no shorting
- Ignore fees/slippage in Phase 1 (note in report)

### 5.3 Backtest Metrics
| Metric | Target |
|---|---|
| Annualized return | Compare vs benchmarks |
| Sharpe ratio | Risk-free rate = 0 or 3% |
| Maximum drawdown | Peak-to-trough decline |
| Turnover ratio | Optional, for sanity check |

### 5.4 Benchmarks
- 000300.SH (CSI 300)
- 000001.SH (SSE Composite)
- Equal-weight all-market index (optional)

---

## 6. Project Structure

```
quant/
├── data/A股数据/              # Raw data (existing)
├── src/
│   ├── config.py              # Hyperparams, paths
│   ├── data_loader.py         # Read CSVs, build MultiIndex DataFrame
│   ├── features.py            # Feature engineering
│   ├── dataset.py             # Sliding window + PyTorch Dataset + normalization
│   ├── models.py              # LSTM/GRU model definitions
│   ├── train.py               # Training loop
│   ├── evaluate.py            # IC/ICIR/metrics computation
│   └── backtest.py            # Trading strategy + vectorized backtest
├── docs/superpowers/specs/    # Design documents
├── 实验.md                    # Experiment log
└── requirements.txt
```

---

## 7. Data Split

| Split | Period | Purpose |
|---|---|---|
| Train | 2019-01-01 to 2024-12-31 | Model training |
| Validation | 2025-01-01 to 2025-12-31 | Hyperparameter tuning, early stopping |
| Test (optional) | 2026-01-01 to present | Final backtest before live trading |
| Live | 2026-06-01 to 2026-06-12 | Simulated trading competition |

---

## 8. Simulated Trading Workflow

1. Wait for daily data update (~18:00-19:00 after market close)
2. Run model inference on the latest 20-day window for all stocks
3. Generate buy/sell signals based on predicted scores
4. Execute orders before 9:30 AM next trading day via 同花顺 app
5. Maintain full position at all times (competition rule)

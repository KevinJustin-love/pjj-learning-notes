## 5.18

一些可能用得上的 agent 架构：

https://mp.weixin.qq.com/s/tJxuCqqghNZyM2CQB36Mfg

- https://github.com/TauricResearch/TradingAgents TradingAgents，以及由他衍生的
- https://github.com/hsliuping/TradingAgents-CN 上述改造版
- ...

上面这些 agent 架构只是完成基础框架 (模型训练) 后续的优化加分点

---

参考 grok 检索的结果：https://grok.com/c/0cf6cee6-b50f-42f6-b710-ff3be95c9449?rid=bcf66e0e-464d-4dec-88ca-19119ea8f96d

---


# 🚀 DLQuant 全工作流交接文档（换窗口必读）

> **生成时间**: 2026-06-12 凌晨（D11 收盘后 / D12 早晨）
> **用途**: 新对话窗口的 Claude 快速拿到全部上下文
> **比赛剩余**: D12 (今天) 是最后一天

---

## 一、🌐 服务器 & 路径

```bash
# === 当前 SSH (2026-06-12) ===
ssh 
密码: 

# ~/.ssh/config 已配置:
Host zyj
    HostName px-cloud2.matpool.com
    Port 28677
    User root
    StrictHostKeyChecking no
    UserKnownHostsFile /tmp/ssh_known_hosts
    ServerAliveInterval 60

# === SSH 一键登录（推荐）===
sshpass -p 'TTi1lm8W%3s+}6u-' ssh -F ~/.ssh/config -o ProxyCommand=none zyj

# 若代理冲突报 "Connection closed by 127.0.0.1 port 7897":
unset ALL_PROXY HTTP_PROXY HTTPS_PROXY http_proxy https_proxy all_proxy

# === 路径 ===
本地: /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/
服务器: /mnt/fdlfinal/dlquant/

# === 数据更新 ===
ssh zyj 'cd /mnt/fdlfinal/dlquant && git pull'
# (Git 仓库每日 push 新数据，由助教维护)
```

---

## 二、📂 项目结构

```
dlquant/
├── zyj/                                  ← 我的工作目录
│   ├── data/                             # 原始数据
│   │   ├── preprocessor.py
│   │   └── cleaned_panel.parquet         (01_preprocess 产出)
│   ├── features/                         # 特征工程
│   │   ├── pipeline.py
│   │   └── features.parquet              (02_features 产出)
│   ├── model/                            # 模型定义
│   │   ├── dlinear.py    ← 比赛主力
│   │   ├── gru.py
│   │   ├── lstm.py
│   │   ├── mlp.py
│   │   ├── transformer.py
│   │   └── patchtst.py
│   ├── zoo/                              # 训练好的模型权重 (.pt)
│   │   ├── zoo_dlinear_v1.pt             ⭐ baseline (RankIC +0.0982)
│   │   ├── zoo_dlinear_v1_ft.pt          (D10 用 ep1 微调)
│   │   ├── zoo_dlinear_v1_ft_v2.pt       ⭐⭐⭐ Catastrophic 反例
│   │   ├── zoo_gru.pt / lstm / trans / patch / mlp
│   ├── TradingAgents/agent_filters/      # Agent 体系
│   ├── scripts/                          # 全部脚本 (60+)
│   ├── reports/                          # 每日 plan + reflection
│   ├── artifacts/                        # 回测产物 (csv/png)
│   └── conclusion/                       # 结论文档
└── (其他人目录)
```

---

## 三、🛠 脚本清单（最常用置顶）

### 🔥 D 日实战流（每天用这 4 个）

```
zyj/scripts/
├── 17_daily_actions.py       ⭐⭐⭐ 每日推荐 (模型 top-K)
├── 41_news_agent_d11.py      ⭐⭐⭐ F3 风向 Agent (deepseek-chat)
│   └── (D12 可复制为 42_news_agent_d12.py, 改 NEWS_DATE)
├── 28_finetune_v1_dlinear.py     v1_ft 微调脚本
└── 38_finetune_v1_dlinear_v2.py  ⭐ Catastrophic 反例脚本
```

### 📊 数据 + 特征

```
01_preprocess.py        清洗 → cleaned_panel.parquet
02_features.py          因子 → features.parquet
14_feature_analysis.py  特征系统分析
15_factor_test.py       因子有效性
30_augment_features.py  增量因子注入
extract_factors.py      因子抽取
```

### 🤖 模型训练

```
03_train.py                 v1 baseline 训练
04_eval.py                  评估 RankIC
04_train_xst.py             xst 双塔
10_train_zoo.py             ⭐ 6 模型动物园训练
11_eval_zoo.py              6 模型横向 RankIC
12_backtest_zoo.py          6 模型回测
25_train_final_for_comp.py  比赛最终模型
31_train_zoo_with_factors_v3.py  加因子重训
24_infer_zoo_range.py       区间推断
```

### 📈 回测 + 网格

```
05_backtest_grid.py             基础网格 N×k
05_backtest_hybrid_grid.py      混合网格
16_simple_backtest.py           简单回测
18_calibrate_10day.py           10 日校准
19_calibrate_cross_w5.py        交叉验证
20_fine_grid_Nk.py              N×k 细网格
22_backtest_xst_from_pred.py    xst 从预测回测
26_eval_ckpt_on_comp_val.py     ckpt 验证
27_export_final_preds.py        导出预测
30_backtest_v1ft_f3.py          ⭐ v1_ft + F3 混仓
```

### 🌐 Agent 系列 (32-41)

```
32_news_agent_d3.py    D3 风向
33_news_agent_d4.py    D4 风向
34_news_agent_d5.py    D5 风向
35_news_agent_d8.py    D8 风向
39_news_agent_d9.py    D9 风向
40_news_agent_d10.py   D10 风向
41_news_agent_d11.py   D11 风向 ⭐ 模板
33_oos_agent_vs_pure.py        Agent vs 纯模型 OOS
34_comp_agent_sweep_final.py   Agent 扫参
29_f3_trend_for_62.py          F3 趋势抽取
```

### 🔬 深度分析

```
07_five_track_compare.py    5 轨道横评
13_ensemble.py              模型集成
23_daily_trace_window.py    每日穿仓窗口
23_plot_nav_vs_hs300.py     净值 vs 沪深 300
31_deep_analysis_12.py      12 只股深度
32_eval_and_plot.py         评估画图
```

---

## 四、🤖 Agent 体系（F1/F2/F3 + Reasoner）

```
zyj/TradingAgents/agent_filters/
├── STRATEGY.md           ⭐ Agent 策略说明
├── agent_macro.py        F1 宏观大盘 (LLM 判断)
├── agent_section.py      F2 板块轮动
├── agent_news.py         F3 主题风向 ⭐ 最常用
├── agent_topn.py         候选股截断 (top N)
├── deepseek_lite.py      DeepSeek API 封装
├── st_filter.py          ST 股过滤
├── limit_filter.py       涨跌停过滤
├── bt_window.py          回测窗口
├── plot_compare.py       Agent 对比可视化
├── run_all.sh            一键全跑
```

### LLM 配置

```python
# 在 deepseek_lite.py 里
F3 主题:  deepseek-chat (快 + 便宜)
Reasoner: deepseek-reasoner (深 + 慢)

# 新服务器可能缺 openai 库:
pip install -q openai
```

### F3 Agent 输入/输出

```
输入:
  - cleaned_panel.parquet (D-1 收盘价 + 涨幅)
  - 当日新闻（手工拼接到 prompt）
  - PE/市值/行业映射表

输出: zyj/reports/D{X}_news_wind.md
  - 主题 list, 每个主题有:
    * 概率 (0.0 ~ 1.0)
    * 持续天数 (1-7)
    * 推荐股票 list
    * 推荐原因
  - 大盘观点
  - 风险预警
```

### 跑新一天的 F3 Agent

```bash
# 1. 复制最近的 agent 脚本作为新一天模板
ssh zyj 'cd /mnt/fdlfinal/dlquant/zyj/scripts && cp 41_news_agent_d11.py 42_news_agent_d12.py'

# 2. 修改日期 (用 sed 慎用, 推荐 Edit 工具一行一行改)
# 关键变量: NEWS_DATE = "20260612"
#          OUT_FILE  = "zyj/reports/D12_news_wind.md"

# 3. 跑
ssh zyj 'cd /mnt/fdlfinal/dlquant && python zyj/scripts/42_news_agent_d12.py'

# 4. 拉回本地
sshpass -p 'TTi1lm8W%3s+}6u-' scp -F ~/.ssh/config -o ProxyCommand=none \
  zyj:/mnt/fdlfinal/dlquant/zyj/reports/D12_news_wind.md \
  /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/zyj/reports/
```

---

## 五、🔄 完整 D 日工作流（标准模板）

```
═══════════ 早上 (开盘前) ═══════════
1. 拉新数据 (前一天收盘后助教 push)
   ssh zyj 'cd /mnt/fdlfinal/dlquant && git pull'

2. 重跑特征
   ssh zyj 'cd /mnt/fdlfinal/dlquant && \
     python zyj/scripts/01_preprocess.py && \
     python zyj/scripts/02_features.py'

3. 模型推断 top-K
   ssh zyj 'cd /mnt/fdlfinal/dlquant && \
     python zyj/scripts/17_daily_actions.py'
   # → 产 reports/D{X}_actions.csv (模型 top 50)

4. F3 风向 Agent
   ssh zyj 'cd /mnt/fdlfinal/dlquant && \
     python zyj/scripts/41_news_agent_d11.py'   # 改日期
   # → 产 reports/D{X}_news_wind.md

5. 拉回本地审视
   scp ... reports/D{X}_*.md → 本地

6. Claude 综合 4 步交叉验证:
   候选 = F3 主题命中 ∩ 模型 Top 50 ∩ PE < 80 ∩ D-1 涨幅 1~9%
   产出 reports/D{X}_final_plan.md (写到本地, 同步到服务器)

═══════════ 09:15-09:25 ═══════════
按 plan 集合竞价 SELL

═══════════ 09:30-10:30 ═══════════
按 plan BUY (注意涨停规避)

═══════════ 14:30-15:00 ═══════════
盘面观察, 极端情况按风险预案微调

═══════════ 晚上 ═══════════
1. 截图实盘 + 同学盘
2. Claude 复盘写 D{X}_reflection.md
3. 准备明日 plan
```

---

## 六、🔬 核心模型 (DLinear) 入参出参

```python
# zoo_dlinear_v1.pt 配置
input_window = 30        # 30 日历史
hidden = 64
output_window = 5        # 预测未来 5 日累计收益
features = ~50 列         # OHLCV + 因子
target = "Y_5d"          # 未来 5 日累计

# 训练
loss = MSE + 0.5 * RankIC_loss
optimizer = AdamW(lr=1e-3)
epochs = 50, early_stop on val RankIC

# 推断
model.eval() → 每股 score
日 top 50 → F3 交叉 → 最终 8-12 只
```

### v1_ft 微调（Catastrophic Finetune 发现）

```
38_finetune_v1_dlinear_v2.py 关键发现:

Train: 4/1 - 5/22 (老段, 因子有效)
Val:   5/25 - 6/1

baseline (v1_ft):  Val RankIC = +0.0982 ✅
ep 1 微调:         Val RankIC = +0.0445
ep 2 微调:         Val RankIC = -0.0495 ⚠ 翻负
ep 3 微调:         Val RankIC = -0.0823 ❌

→ 训练 loss 单调下降 (拟合越好)
→ 验证 RankIC 单调反向 (alpha 翻负)
= Catastrophic Finetune 实证

实验报告金句:
"非平稳市场下, 微调超过 1 epoch 即触发 factor inversion,
 模型把刚学到的'最近模式'当成永真, 在下一周完全反向。"
```

---

## 七、📅 D1-D11 实战日志（一图速览）

```
Date     Equity      Daily    Cum     Note
─────────────────────────────────────────────────
D0       1,000,000   +0.00%   +0.00%  起点
D1       1,018,445   +1.84%   +1.84%
D5         957,310    ↓       -4.27%  谷底连跌
D8         940,591    ↓       -5.94%  最低点 ⚠
D9       1,011,539   +7.55%   +1.15%  ⭐ 反弹日
D10      1,000,813   -1.06%   +0.08%  转正
D11      ?           ?        ?       化工日 (今早)
D12      最后一天                       D12 不调仓

大盘累计: -1.42%
你超大盘: +1.50pp
```

### Plan vs 直觉对比 ⭐⭐⭐ 报告金钩

| 日 | Plan 推荐 | 你实际 | 救场 |
|---|---|---|---|
| D8 | SELL 阳光, BUY 宝鹰 | 不卖阳光, 加昊志 | +1.8pp |
| D9 | SELL 4 (长飞/风华/商络/...) | 都不卖, 4 只涨停 | +2.7pp |
| D10 | 减仓 + BUY 4 主题 | KEEP 阳光 + 部分换 | +1.5pp |

**结论**: 板块周期 + 信仰仓 > Plan SELL 推荐

---

## 八、💼 D10 末持仓 → D11 调仓

### D10 末 11 只（开盘前的起点）

```
000608 阳光股份 27500 ⭐  +49.90%  (信仰仓)
600522 中天科技    500    +85.01%  (减仓后)
000636 风华高科   2200     +4.79%
600487 亨通光电    700     +1.06%  (D10 NEW)
688012 中微公司    400     -0.14%
002756 永兴材料   1100     -2.36%  (D10 NEW)
300488 恒锋工具   2200     -1.93%
002371 北方华创    200     -1.99%
601869 长飞光纤    100     -8.00%  (减仓后)
300975 商络电子    500    -20.95%  ⚠ 拖累
688525 佰维存储    115    -27.17%
现金: 89,836 (8.9%)
```

### D11 操作（已写入 D11_final_plan.md）

```
SELL: 300975 商络电子 500 股 @ 39.30 → 释放 ~19,650
BUY:  603379 三美股份  800 股 @ 60.70 → ~48,560 (PE 17)
BUY:  600160 巨化股份 1500 股 @ 40.39 → ~60,585 (PE 26)
KEEP: 10 只不动
```

---

## 九、🌪 F3 D11 4 大主题（最新风向）

```
🥇 化工原料涨价  0.80 / 3 天 / F3 最强 ← D11 主攻
   三美/巨化/江瀚新材/鼎龙科技/彤程新材
   催化: 硫磺破万 + 中东霍尔木兹运输扰动

🥈 半导体国产替代 0.70 / 5 天 ← 已持有 3 只
   银河微电/长川科技/江丰电子/海光信息/杰华特
   催化: AI 算力 + 车规存储芯片 3 月涨 180%

🥉 旅游景点 0.60 / 3 天 ← D10 涨过, 不追
   长白山/西藏旅游/大连圣亚

补 黄金/避险 (Reasoner 提示)
   山东黄金/中金黄金/紫金矿业
   催化: 央行 19 月增持 + 中东风险
```

---

## 十、📚 已积累 reports/ 文档（按时间）

```
D1_reflection_61.md
D2_final_plan.md / D2_final_plan_B.md / D2_final_plan_B_9stocks.md
D2_12stocks_deep_analysis.md
D3_final_plan.md / D3_news_wind.md
D4_final_plan.md / D4_final_plan_v2.md / D4_news_wind.md
D5_final_plan.md / D5_news_wind.md
D8_final_plan.md / D8_news_wind.md
D9_final_plan.md / D9_news_wind.md
D10_final_plan.md / D10_news_wind.md
D11_final_plan.md ⭐ / D11_news_wind.md
buy_list_61.md / strategy_for_61.md
plan_B_oos.png
HANDOFF_WORKFLOW.md ← 本文件
```

---

## 十一、🔬 实验报告 4 大重磅章节

```
⭐⭐⭐ Catastrophic Finetune 发现
  文件: zoo_dlinear_v1_ft_v2_history.csv (RankIC 翻负曲线)
  脚本: 38_finetune_v1_dlinear_v2.py
  字数: 2500

⭐⭐⭐ Plan vs 直觉 12 天双盲对比
  数据: D1-D11 每天 plan SELL 列表 vs 用户实际 → 涨跌
  亮点: D9 plan 推荐卖的 4 只全部涨停
  字数: 2500

⭐⭐⭐ F3 系统性低估"避险板块"
  现象: D10 小金属 F3 0.60 最低 → 实际最抗跌 -0.43%
       D10 光通信 F3 0.70 推荐 → 实际跑输 -2.05%
  原因: LLM 主题倾向 momentum, 不识别 mean-reversion
  字数: 2000

⭐⭐ 6 模型横向对比
  MLP / LSTM / GRU / Transformer / DLinear / PatchTST
  DLinear 取胜 (最简单 + RankIC 最高)
  字数: 3000
```

### 推荐章节结构

```markdown
1. 摘要 (300 字)
2. 引言 + 比赛背景 (500)
3. 数据 + 特征工程 (1500)
4. 6 模型横向对比 (3000) ⭐
5. v1_ft 微调实验 (1500) ⭐
6. ★ Catastrophic Finetune 发现 (2500) ⭐⭐⭐
7. 4-Agent 系统 (F1/F2/F3/Reasoner) (3000) ⭐
8. 实战 D1-D12 全程 (5000) ⭐
9. ★ Plan vs 直觉 双盲对比 (2500) ⭐⭐⭐
10. ★ F3 系统性低估避险板块 (2000) ⭐⭐⭐
11. 改进 + Future Work (2000)
12. 结论 (500)
─── 合计 ~24,800 字 (远超普通同学) ───
```

---

## 十二、🆘 常用命令速查

```bash
# === SSH ===
sshpass -p 'TTi1lm8W%3s+}6u-' ssh -F ~/.ssh/config -o ProxyCommand=none zyj

# === 拉取报告到本地 ===
sshpass -p 'TTi1lm8W%3s+}6u-' scp -F ~/.ssh/config -o ProxyCommand=none \
  zyj:/mnt/fdlfinal/dlquant/zyj/reports/D12_news_wind.md \
  /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/zyj/reports/

# === 推本地 plan 到服务器 ===
sshpass -p 'TTi1lm8W%3s+}6u-' scp -F ~/.ssh/config -o ProxyCommand=none \
  /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/zyj/reports/D12_final_plan.md \
  zyj:/mnt/fdlfinal/dlquant/zyj/reports/

# === 拉数据 + 重跑特征 + 出 daily_actions ===
ssh zyj 'cd /mnt/fdlfinal/dlquant && \
  git pull && \
  python zyj/scripts/01_preprocess.py && \
  python zyj/scripts/02_features.py && \
  python zyj/scripts/17_daily_actions.py'

# === 跑某天 F3 Agent ===
ssh zyj 'cd /mnt/fdlfinal/dlquant && python zyj/scripts/41_news_agent_d11.py'

# === 查模型 RankIC ===
ssh zyj 'cd /mnt/fdlfinal/dlquant && python zyj/scripts/11_eval_zoo.py'

# === 检查 zoo 模型 ===
ssh zyj 'ls -la /mnt/fdlfinal/dlquant/zyj/zoo/*.pt'
```

---

## 十三、⚠ 容易踩的 5 个坑

```
1. SSH 代理冲突
   症状: Connection closed by 127.0.0.1 port 7897
   解法: unset ALL_PROXY HTTP_PROXY ... + -o ProxyCommand=none

2. 新 server 缺 python 库
   常见: openai (跑 F3 agent 必装)
   解法: pip install -q openai

3. F3 Agent 日期 sed 替换重复
   症状: NEWS_DATE 替换错日期 (D9 踩过)
   解法: 用 Edit 工具一行一行改, 不用 sed

4. 服务器换端口后忘记更新 ~/.ssh/config
   症状: ssh: connect to host port 22 No route
   解法: 立即 Edit ~/.ssh/config 改 Port

5. Plan 推荐卖股 ≠ 必须卖
   规则: 板块周期 + 信仰仓 > Plan SELL
   案例: D9 plan 推荐卖 4 只都涨停了
```

---

## 十四、🎯 D12 (今天 6/12 最后一天) 预案

```
═══════════ D12 操作原则 ═══════════
❌ 不要 D12 调仓 (执行风险大)
✅ 让 D11 调整后的 12 只持仓自然收盘
✅ 收盘后立即写实验报告最终版

═══════════ D12 期望 ═══════════
  - 阳光股份继续涨 +3~5% (累计 +50%+)
  - 化工延续 (F3 主题 3 天)
  - 半导体超跌反弹未完
  - D12 整体: +1~2%
  - D12 末累计: +1.0% ~ +3.0%

═══════════ 实验报告 ═══════════
6/12 收盘后开始写, 6/12 晚 ~ 6/13 早交
重点章节: Catastrophic Finetune + Plan vs 直觉 + F3 避险板块
目标: 进前 10%
```

---

## 十五、💡 新窗口开局 prompt 模板

复制下面整段, 粘贴到新窗口第一句即可:

```
我是参加 USTC 深度学习比赛 (6/1-6/12) 的同学。
今天是 D12 (6/12), 比赛最后一天。
当前累计 +0.08% (D10 末), D11 已按 plan 调仓。

服务器: ssh zyj (已配 ~/.ssh/config, 端口 28677)
本地: /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/

请先读这两个文件了解全局:
1. zyj/reports/HANDOFF_WORKFLOW.md  ← 工作流 + Agent + 模型清单
2. zyj/reports/D11_final_plan.md    ← D11 完整方案

今天我想做的事情是: [XXX]
```

---

## 十六、🔥 一键 D 日推荐（懒人模式）

```bash
# 跑完产出 D12 所有材料 (在服务器上一行命令)
ssh zyj 'cd /mnt/fdlfinal/dlquant && \
  git pull 2>&1 | tail -2 && \
  python zyj/scripts/01_preprocess.py 2>&1 | tail -3 && \
  python zyj/scripts/02_features.py 2>&1 | tail -3 && \
  python zyj/scripts/17_daily_actions.py 2>&1 | tail -10'

# 然后跑 F3 (需要先复制 41 → 42 改日期)
ssh zyj 'cd /mnt/fdlfinal/dlquant && python zyj/scripts/42_news_agent_d12.py 2>&1 | tail -20'

# 最后拉回本地
sshpass -p 'TTi1lm8W%3s+}6u-' scp -F ~/.ssh/config -o ProxyCommand=none \
  zyj:/mnt/fdlfinal/dlquant/zyj/reports/D12_*.md \
  /Users/zhangyujie/Desktop/4courses/cs/DeepLearning/dlquant/zyj/reports/
```

---

📁 **本文件位置**: `zyj/reports/HANDOFF_WORKFLOW.md`
🎯 **使用方式**: 新窗口第一句让 Claude `Read` 这个文件
🔄 **服务器换端口时**: 仅更新本文档第一章 + `~/.ssh/config` 即可

> "工作流稳定, 心态不慌; 信仰仓不卖, 化工冲一把; D12 不动手, 报告写到飞。"

---

**生成时间**: 2026-06-12
**作者**: Jessica-Zhangyj (zzhangyujie051212@gmail.com)
**对应 Claude 模型**: Opus 4.7

# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build

```bash
xelatex -synctex=1 -interaction=nonstopmode project_summary.tex
xelatex -synctex=1 -interaction=nonstopmode project_summary.tex  # second pass for TOC
```

`latexmk -xelatex project_summary.tex` also works for automatic multi-pass builds.
TeX Live 2024 is at `D:\LaTex\texlive\2024\bin\windows\`.

## Project overview

This is a LaTeX report summarizing a USTC "深度学习基础" 2026 course project on A-share stock selection. The report documents two parallel methodological approaches:

- **XGBoost + RL pipeline** (`project_summary.tex`): The primary report. Covers data processing, feature engineering, tradeable label construction, leakage auditing, XGBoost regression-to-rank, PPO/DDPG/TD3 RL models, and strict backtesting with limit-up/down constraints. The final recommended strategy uses `tradeable_rank_5d` label with XGBoost, n=5, k=1, and liquidity-based tie-breaking.
- **DLinear + LLM Agents pipeline** (`section_methodology.tex`): A secondary methodology section intended to be `\input{}` into another document. Describes a lightweight DLinear time-series model, catastrophic finetune discovery, a 4-agent (F1/F2/F3/Reasoner) news sentiment system, and a human-in-the-loop decision framework.

The implementation code (Python scripts for data pipelines, model training, backtesting) lives in the parent directory `../src/`. Data lives in `../data/`.

## File structure

- `project_summary.tex` — Main document. Self-contained; uses `ctexart` class for Chinese support. Includes abstract, data processing, model/experiment design, results, excluded experiments, and final recommended configuration.
- `section_methodology.tex` — Fragment intended for `\input{}` into a larger report. References figures in `figs/` and relies on packages loaded by the parent document (`ctex`, `graphicx`, `booktabs`, `amsmath`, `hyperref`, `geometry`, `xcolor`, `tabularx`).
- `figs/` — PNG figures for both documents (workflow diagrams, training curves, agent schemas, NAV curves, holdings PnL).
- `img/` — PNG figures primarily for `project_summary.tex` (account value curves, feature comparison charts, RL comparison, ablation results).

## Key LaTeX notes

- **Engine**: Must use XeLaTeX (not pdfLaTeX) — the `ctexart` document class requires it for Chinese font handling.
- **Fonts**: `ctexart` auto-configures Chinese fonts. No custom font setup needed on this machine.
- **Build artifacts**: `.aux`, `.log`, `.out`, `.toc`, `.synctex.gz` are generated and should not be committed or edited.
- The `.tex` files use custom commands `\good`, `\explore`, `\excluded` defined in the preamble of `project_summary.tex` for color-coded status labels.

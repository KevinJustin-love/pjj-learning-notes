# 特征构建与特征选择 — 完整说明

> **项目**: USTC 深度学习基础 2026 — A 股 5 日截面收益预测  
> **维护**: zyj 组  
> **关联代码**: `zyj/features/pipeline.py`, `zyj/scripts/01_preprocess.py`, `02_features.py`, `14_feature_analysis.py`, `15_factor_test.py`  
> **关联报告**: `section_methodology.tex`, `section_experiments.tex`, `ALL_EXPERIMENTS_SUMMARY.md`

---

## 0. 读本文前先弄清两个「维数」

本项目中「特征维数」有两套口径，**都对，但指的不是同一件事**：

| 口径 | 维数 | 含义 |
|------|------|------|
| **因子体系（报告口径）** | **50 维** | 按经济含义划分的四类因子预算：量价 20 + 资金流 8 + 估值 6 + 微结构 16 |
| **模型入模（代码口径）** | **20 维** | `QuantitativeFeaturePipeline.all_features`，DLinear 训练/推断实际使用的列 |

关系可以概括为：

```
原始数据 (OHLCV + metric + 8 列 moneyflow)
    ↓ 02_features.py
因子体系 ~50 维（概念分类，含 raw moneyflow、K/D/J 等）
    ↓ 冗余合并 + 去重
模型入模 20 维 (all_features) × 30 日窗口 → DLinear
```

**为什么不矛盾？**  
50 维是「设计了哪些信息源」；20 维是「工程上合并冗余后喂给模型的独立列」。例如 8 列 raw moneyflow 在体系里占 8 维预算，入模时压缩为 `smart_money_net` + `main_force_power` 两列。

---

## 1. 整体流水线

```mermaid
flowchart TB
    subgraph S1["Step 1 — 01_preprocess.py"]
        A1[daily / metric / moneyflow CSV] --> A2[cleaned_panel.parquet]
    end
    subgraph S2["Step 2 — 02_features.py"]
        A2 --> B1[QuantitativeFeaturePipeline]
        B1 --> B2[features.parquet]
    end
    subgraph S3["Step 3 — dataset/builder.py"]
        B2 --> C1[滑动窗口 L=30]
        C1 --> C2["X ∈ R^(N×30×20)"]
    end
    subgraph S4["特征选择实验（离线）"]
        D1[14_feature_analysis.py]
        D2[15_factor_test.py]
        D3[QuantaAlpha +14 消融]
    end
    B2 --> D1
    B2 --> D2
    D1 --> E[决策: 保持 20 维 baseline]
    D2 --> E
    D3 --> E
    C2 --> F[DLinear 训练 / 17_daily_actions 推断]
```

### 1.1 脚本与产物

| 步骤 | 脚本 | 输入 | 输出 |
|------|------|------|------|
| 清洗 | `zyj/scripts/01_preprocess.py` | `data/{daily,metric,moneyflow,...}` | `zyj/artifacts/cleaned_panel.parquet` |
| 特征 | `zyj/scripts/02_features.py` | `cleaned_panel.parquet` | `zyj/artifacts/features.parquet` |
| 诊断 | `zyj/scripts/14_feature_analysis.py` | `features.parquet` | `feature_single_ic.csv`, `feature_vif.csv`, `feature_analysis_report.md` 等 |
| 高阶因子 | `zyj/scripts/15_factor_test.py` | features + cleaned | `factor_test_results.csv` |
| 训练 | `zyj/scripts/10_train_zoo.py` 等 | features + builder | `zoo_dlinear*.pt` |

---

## 2. 原始数据与清洗（Step 1）

### 2.1 数据来源

`01_preprocess.py` 读取 6 类原始数据，合并为 `(ts_code, trade_date)` 主键大表：

| 类别 | 字段 | 用途 |
|------|------|------|
| 基础量价 | open, high, low, close, vol, amount, pct_chg, vwap | 动量、技术指标、量比 |
| 基本面 (metric) | turnover_rate, pe_ttm, pb, total_mv | 估值、规模、换手 |
| 资金流 (moneyflow) | buy/sell × sm/md/lg/elg 共 8 列 | 主力行为、聪明钱 |

### 2.2 单位约定（影响因子公式）

| 字段 | tushare 默认单位 |
|------|------------------|
| `daily.amount` | 千元 |
| `daily_basic.total_mv` | 万元 |
| `moneyflow.*_amount` | 万元 |

计算 `smart_money_net` 时，moneyflow 金额 × **10** 与 `amount`（千元）对齐。可在构造 pipeline 时传 `moneyflow_to_amount_unit=1.0` 覆盖。

### 2.3 样本过滤

- 剔除 ST、北交所 (`.BJ`)、退市股  
- 按 `trade_cal` 对齐交易日历，保证单股序列连续  
- 全市场约 **4,500** 只可投资标的，panel 约 **7.8×10⁶** 行（2022–2026/06）

---

## 3. 因子体系：50 维四类分类

报告与实验章节采用的**因子 taxonomy**（`ALL_EXPERIMENTS_SUMMARY.md` §2.1）：

| 类别 | 预算维数 | 代表因子 | 单因子 RankIC 量级 |
|------|----------|----------|-------------------|
| **量价基础** | 20 | ret_1/3/5/10/20, RSI_14, BOLL_width, vwap_bias, vol, pct_chg, vol_ma_5_ratio | ±0.02 ~ ±0.05 |
| **资金流** | 8 | 8 列 raw moneyflow；衍生 mfFlowPriceDiv, main_force_power, smart_money_net | ±0.005 ~ ±0.035 |
| **估值 / 基本面** | 6 | pb, pe_ttm, ln_mv, turnover_rate, is_loss, 行业 one-hot top-K（设计项） | ±0.01 ~ ±0.02 |
| **微结构 / 情绪** | 16 | MACD_hist, sentiment_j, K/D/J, silentRise, closingTapeStrength 等 | ±0.003 ~ ±0.017 |

> **说明**: 四类之间有**语义重叠**（如 MACD 可归量价也可归微结构），50 是设计预算而非 50 个正交列的简单相加。

---

## 4. 特征构建详解（Step 2 — `QuantitativeFeaturePipeline`）

实现文件：`zyj/features/pipeline.py`  
主入口：`pipe.fit_transform(df)` → 写入 `features.parquet`

### 4.1 流水线四步

```
① 字段校验 + (ts_code, trade_date) 排序
② pe_ttm 缺失修复 + is_loss 哑变量
③ groupby(ts_code) 单股时序特征（rolling / talib / ewm，只看过去）
④ dropna 剔除预热期 NaN
⑤ groupby(trade_date) 截面 Winsorize[1%,99%] + Z-score
```

### 4.2 逐类衍生公式

#### A. 动量 — 5 维

对每只股票内部，按 `close` 计算：

\[
\text{ret}_n(t) = \frac{\text{close}(t)}{\text{close}(t-n)} - 1, \quad n \in \{1,3,5,10,20\}
\]

| 列名 | 含义 |
|------|------|
| `ret_1` ~ `ret_20` | 多尺度累计收益，捕捉短/中/长期动量 |

#### B. 量价结构 — 4 维（含 2 维 raw）

| 列名 | 公式 | 含义 |
|------|------|------|
| `pct_chg` | 原始字段 | 当日涨跌幅 |
| `vol` | 原始字段 | 成交量 |
| `vol_ma_5_ratio` | vol / mean(vol, 5) | >1 放量，<1 缩量 |
| `vwap_bias` | (close − vwap) / vwap | 收盘价相对成交均价偏离，>0 尾盘偏强 |

#### C. 技术指标（TA-Lib）— 7 维计算，4 维入模

| 列名 | 参数 | 入模？ |
|------|------|--------|
| `MACD_hist` | MACD(12,26,9) 柱 | ✅ |
| `RSI_14` | RSI(14) | ✅ |
| `BOLL_width` | BBANDS(20,2,2)，(upper−lower)/middle | ✅ |
| `K`, `D`, `J` | STOCH(9,3,0,3,0)，J=3K−2D | ❌（仅中间量） |
| `sentiment_j` | J − EMA(J, 5) | ✅ |

#### D. 资金流衍生 — 2 维入模（来自 8 列 raw）

| 列名 | 公式 | 含义 |
|------|------|------|
| `smart_money_net` | [(buy_elg+buy_lg)−(sell_elg+sell_lg)]×10 / amount | 聪明钱净流入占成交额比例 |
| `main_force_power` | (buy_elg+buy_lg) / total_mv | 主力买入相对市值强度 |

8 列 raw moneyflow **保留在 `features.parquet` 中**（供高阶因子实验），但 **DLinear baseline 不直接入模**。

#### E. 估值 / 基本面 — 6 维

| 列名 | 处理 | 含义 |
|------|------|------|
| `ln_mv` | log(total_mv) | 对数市值，压幂律分布 |
| `turnover_rate` | 原始 + 截面标准化 | 换手率 |
| `pe_ttm` | NaN→0；原 NaN 记 is_loss=1 | 滚动市盈率 |
| `pb` | 原始 + 截面标准化 | 市净率 |
| `is_loss` | pe_ttm 原 NaN → 1 | 亏损股标记 |
| 行业 one-hot | **设计中有，基础 pipeline 未实现** | — |

### 4.3 模型入模 20 维完整清单

`pipe.all_features` = Token1 ∪ Token2 ∪ Token3（去重保序）：

**Token1 — 市场风格与实力（6）**

```
ln_mv, turnover_rate, pe_ttm, pb, main_force_power, is_loss
```

**Token2 — 情绪与技术指标（4）**

```
MACD_hist, RSI_14, BOLL_width, sentiment_j
```

**Token3 — 资金流向与动能（10）**

```
pct_chg, vol, smart_money_net,
ret_1, ret_3, ret_5, ret_10, ret_20,
vol_ma_5_ratio, vwap_bias
```

> Transformer 实验可按 Token 切片；DLinear / MLP / LSTM 等使用 `all_features` 平铺。

### 4.4 50 维体系 → 20 维入模 映射表

| 50 维体系中的信息 | 入模列 | 合并方式 |
|-------------------|--------|----------|
| 8 列 raw moneyflow | smart_money_net, main_force_power | 净流入比 + 主力/市值 |
| K, D, J | sentiment_j | 仅保留 J 的 EMA 乖离 |
| 多尺度 ret + pct_chg + vol + 量比 + vwap | ret_*, pct_chg, vol, vol_ma_5_ratio, vwap_bias | 各自独立保留 |
| MACD / RSI / BOLL | MACD_hist, RSI_14, BOLL_width | 独立保留 |
| 估值字段 | ln_mv, pe_ttm, pb, turnover_rate, is_loss | 独立保留 |
| 行业 one-hot | — | 未实现 |
| silentRise 等高阶因子 | — | 仅离线测试，未注入主流程 |

### 4.5 截面预处理

**标准化列**（`_COLS_TO_NORMALIZE`，共 21 个名字，其中 K/D/J 不入模但参与标准化统计）：

对每个 `trade_date` 截面：

1. **Winsorize**：1%–99% 分位 clip，防止涨跌停/爆雷拉偏  
2. **Z-score**：\(x' = (x - \mu_t)/(\sigma_t + \epsilon)\)

**不做截面 Z-score 的入模列**：`pct_chg`, `vol`, `is_loss`

### 4.6 防泄露设计

| 规则 | 实现 |
|------|------|
| 时序特征只看过去 | 所有 rolling / ewm / talib 在 `groupby('ts_code')` 内 |
| 截面统计不跨日 | Winsorize / Z-score 用 `groupby('trade_date').transform` |
| 标签构造 | `shift(-h)` 仅在单股内部；train/val 之间 purge ≥7 自然日 + embargo 30 日 |
| 特征分析 | `14_feature_analysis.py` 仅用 `train_end ≤ 20251224` |
| 高阶因子 OOS | `15_factor_test.py` 在 20260101–20260430 验证 |

---

## 5. 模型输入格式

`TimeSeriesDatasetBuilder`（`zyj/dataset/builder.py`）将特征表切成：

| 张量 | 形状 | 含义 |
|------|------|------|
| `X` | (N, L, F) = (N, **30**, **20**) | 过去 30 个交易日的标准化特征 |
| `Y_5d` | (N,) | 未来 5 日累计收益 |
| `Y_30d` | (N,) | 未来 30 日累计收益（双头辅助） |

训练脚本（`10_train_zoo.py`, `25_train_final_for_comp.py`）统一使用：

```python
from zyj.features import QuantitativeFeaturePipeline
pipe = QuantitativeFeaturePipeline()
feature_cols = list(pipe.all_features)  # 20 维
```

---

## 6. 特征选择方法论

本项目的特征选择**不是**「从 50 列里 Lasso 筛出 20 列」，而是：

1. **构建**：按领域知识设计 50 维因子体系  
2. **合并**：工程上压缩冗余 → 20 维 `all_features`  
3. **验证**：IC / VIF / PCA / Lasso 确认 20 维质量  
4. **扩展测试**：高阶 moneyflow 因子 + 消融 → **否决注入**  
5. **训练侧隐式选择**：MSE + 0.5×RankIC loss 让模型自动加权  

### 6.1 单特征 RankIC（`14_feature_analysis.py`）

**目的**：衡量每个特征**单独**对未来收益的排序能力。

**方法**：
- 对每个 `trade_date`，计算 `Spearman(特征, Y_5d)` 与 `Spearman(特征, Y_30d)`  
- 对所有交易日取均值 → Mean Daily RankIC  
- 数据截止：`train_end = 20251224`（防泄露）

**产物**：`zyj/artifacts/feature_single_ic.csv`

**解读标准**：
- \|RankIC\| > 0.02 → 高信号特征  
- 量价 ret 系列、RSI、vwap_bias 通常最强  
- 估值类弱但稳定，提供截面分层信息  

### 6.2 共线性诊断 — VIF（`14_feature_analysis.py`）

**目的**：判断是否需要 PCA 降维或删列。

**方法**：对 20 维特征算 Variance Inflation Factor；VIF > 10 视为严重共线。

**实验结论**（`ALL_EXPERIMENTS_SUMMARY.md` §2.3）：

| 因子 | VIF | 决策 |
|------|-----|------|
| ret_1 | 4.86 | 保留 |
| RSI_14 | 4.49 | 保留 |
| ret_3 | 4.48 | 保留 |
| ret_10 | 3.92 | 保留 |
| main_force_power | 3.76 | 保留 |
| pct_chg | 3.34 | 保留（与 ret_1 相关但保留多尺度） |

**全部 VIF < 5 → 不做 PCA 降维，20 维全保留。**

### 6.3 PCA 与 Lasso（`14_feature_analysis.py`）

| 方法 | 作用 | 结论 |
|------|------|------|
| **PCA** | 看前 K 个主成分解释多少方差 | 存在冗余但可接受；未用于生产降维 |
| **Lasso 路径** | 不同 α 下哪些特征系数非零 | 参考性诊断；最终未据此删列 |

### 6.4 高阶因子单测（`15_factor_test.py`）

在 features + cleaned 面板上，手写 **5 个** QuantaAlpha 风格 moneyflow 因子，2026Q1 OOS 评估：

| 因子 | 含义 | RankIC(5d) | RankIC(30d) | 备注 |
|------|------|------------|-------------|------|
| `mfFlowPriceDiv` | 5 日资金 rank − 5 日收益 rank，市值中性 | +0.0045 | **+0.0335** | 30d 稳定 |
| `sectorFlowRelStrength` | 伪行业内资金强度 × 板块动量 | −0.0066 | **+0.0236** | 30d 稳定 |
| `actBuySellPressure` | 买卖压力 z × 价格沉默 | −0.0081 | −0.006 | 弱 |
| `silentRise` | 低换手温和反转 | +0.0030 | +0.010 | 5d 弱 |
| `closingTapeStrength` | 尾盘 × 主力 × 量比 | −0.0167 | −0.019 | 负向 |

**评估指标**：Mean RankIC、RankICIR（年化）、Top-30 多头 Sharpe、年化单边换手率。

**结论**：
- **30d** 有 2 个稳定正因子 → 支撑 DLinear **双头**（5d 主决策 + 30d 辅助正则）  
- **5d** 全部偏弱（±0.005 量级）→ 比赛短窗以 5d 排序为主（`w_5=1.0`）  
- **不替换** baseline 20 维，仅作分析参考  

每个高阶因子均做 **市值中性化**（截面 OLS 对 ln_mv 回归取残差）。

### 6.5 QuantaAlpha +14 因子注入消融

**实验**（`QuantaAlpha_subsection.tex`, `section_experiments.tex`）：

| 配置 | 特征数 | 2026Q1 累计收益 | Sharpe |
|------|--------|-----------------|--------|
| DLinear baseline | 20（报告亦称 50 维体系 / 22 列科创板实验） | **+9.29%**（Top-30 策略） | **~1.85**（科创板对照） |
| +14 手算 moneyflow 因子 | 20+14=34~36 | +3.94% | 0.62~0.67 |

**失败原因**（QuantaAlpha 小节）：
1. `features.parquet` 已含 8 列 raw moneyflow，DLinear 已从原始字段学到大部分信号  
2. 再注入 z-score/ratio 形式的高阶因子 → **高度共线** → 轻度过拟合  
3. 训练 loss 下降但 **val loss 上升**，val RankIC 从 0.15 退化到 0.12  

**最终决策**：

> **保持 50 维因子体系 / 20 维入模 baseline，不在 `17_daily_actions.py` 中注入 +14 高阶因子。**

### 6.6 训练损失作为隐式特征选择

Loss 设计（`section_methodology.tex`）：

\[
\mathcal{L} = \mathrm{MSE} + 0.5 \cdot \mathcal{L}_{\text{RankIC}}
\]

| Loss | Val RankIC(5d) | 说明 |
|------|----------------|------|
| 纯 MSE | < 0.05 | 点估计优化，排序差 |
| MSE + 0.5 RankIC | ~0.098 | 与选股目标对齐 |

RankIC loss 在训练中对 20 维特征做**软加权**，而非硬删列。

---

## 7. 最终选型决策汇总

| 维度 | 选择 | 未选方案 | 依据 |
|------|------|----------|------|
| 因子体系 | 50 维四类 taxonomy | — | 报告/实验统一口径 |
| 模型入模 | **20 维** `all_features` | 50 列 raw 全喂 | 冗余合并、VIF<5 |
| 高阶因子 | **不注入** +14 | QuantaAlpha LLM 因子 | 5d 弱 + 消融 Sharpe 下降 |
| 降维 | **不做 PCA** | PCA→K 维 | VIF 无严重共线 |
| 删列 | **不删** ret 系列 | Lasso 稀疏 | 多尺度动量有独立价值 |
| 双头 | 5d + 30d | 仅 5d | 30d RankIC 显著更强，辅助正则 |
| 比赛权重 | `w_5=1.0` 纯 5d | 0.5/0.7 混合 | 12 日短窗 5d 反应最快 |

---

## 8. 推理阶段的「二次筛选」（非特征选择）

20 维 → DLinear → `pred_5d` 后，策略层还有**股票池过滤**（`17_daily_actions.py` + 四步交叉验证）：

| 规则 | 参数 |
|------|------|
| ST / 北交所 | 过滤 |
| PE 上限 | < 80 |
| T-1 涨幅 | ∈ [1%, 9%] |
| 与 F3 主题 | 四步交集 |

这是对**候选股**的过滤，不是对 20 维特征维度的子集选择。

---

## 9. 复现命令

```bash
# 1. 清洗
python zyj/scripts/01_preprocess.py \
    --start 20240101 --end 20260612 \
    --out zyj/artifacts/cleaned_panel.parquet

# 2. 特征（会打印 token 切分与 all_features 列表）
python zyj/scripts/02_features.py

# 3. 特征诊断（需 pyarrow + sklearn + matplotlib）
python zyj/scripts/14_feature_analysis.py

# 4. 高阶因子单测
python zyj/scripts/15_factor_test.py --start 20260101 --end 20260430

# 5. 训练 DLinear（20 维 × 30 窗口）
python zyj/scripts/10_train_zoo.py --model dlinear --epochs 20
```

---

## 10. 论文写作建议（避免维数口径打架）

推荐表述：

> 特征工程构建 **50 维因子体系**（量价 / 资金流 / 估值 / 微结构四类），经冗余合并与 VIF 检验后，以 **20 维标准化特征** 在 30 日回看窗口上输入 DLinear；QuantaAlpha 风格 **14 维高阶 moneyflow 因子** 经单因子 IC 与消融回测验证后未注入生产管线。

---

## 11. 相关文件索引

| 文件 | 内容 |
|------|------|
| `zyj/features/pipeline.py` | 特征构建主实现 |
| `zyj/features/README.md` | API 与字段说明 |
| `zyj/dataset/builder.py` | 30×20 滑动窗口 |
| `zyj/scripts/14_feature_analysis.py` | IC / VIF / PCA / Lasso |
| `zyj/scripts/15_factor_test.py` | 5 个高阶因子 OOS |
| `zyj/reports/ALL_EXPERIMENTS_SUMMARY.md` | 实验数值汇总 |
| `zyj/reports/QuantaAlpha_subsection.tex` | +14 消融与 22 维 baseline 说明 |
| `zyj/reports/section_experiments.tex` | 消融图与 50 维 baseline 表述 |

---

*最后更新：2026-06-14*

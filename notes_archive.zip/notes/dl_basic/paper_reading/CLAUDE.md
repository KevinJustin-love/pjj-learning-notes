# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

This repo produces USTC (中国科学技术大学) formatted paper reading reports as compiled LaTeX PDFs. The main workflow is: read an arXiv paper → write a structured reading report in Chinese → compile to PDF with the USTC branding template.

## Repository layout

```
ustc-report/           ← Claude Code skill + report output
  SKILL.md             ← skill definition: template macros, LaTeX syntax cheatsheet, automated build steps
  README.md            ← human-facing skill description
  logo.jpg             ← USTC logo used on title pages
  report/              ← generated report (the deliverable)
    main.tex           ← LaTeX source
    main.pdf           ← compiled output
    img/               ← figures referenced by the report (paper screenshots, etc.)
tmp/                   ← intermediate artifacts (not committed to report)
  paper_2504_13837.pdf ← downloaded paper PDF
  paper_page-*.png     ← extracted paper pages as images
  pdfs*/               ← iteratively rendered report page images (multiple revision rounds)
gpt.txt                ← follow-up literature catalog: papers that address or challenge the original paper's claims
```

## Building the report

```bash
cd ustc-report/report
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex   # second pass for TOC + cross-refs
```

Must use **XeLaTeX** (not pdfLaTeX) — `ctexart` document class requires it.

## The USTC report skill

`ustc-report/SKILL.md` is a Claude Code skill. When a user asks to write a USTC report, Claude should:

1. Copy `logo.jpg` into the target report directory, create `img/` subdirectory
2. Generate `main.tex` using the template skeleton from SKILL.md (which defines custom LaTeX environments: `terminal` for code blocks, `expbox` for results, ablation table helpers `\up`/`\dn`/`\grouprow`)
3. Compile twice with `xelatex`

The defined colors (`absBlue`, `termbg`, `codeblue`, `passgn`, `rowblue`, etc.) and commands (`\termline`, `\exprow`, `\expsep`, `\up`, `\dn`, `\baseline`, `\grouprow`) are part of the template's visual identity — preserve them when editing `main.tex`.

## tmp/ directory conventions

- `tmp/pdfs*/` subdirectories hold rendered page images from successive revision rounds (`pdfs` → `pdfs_updated` → `pdfs_final` → `pdfs_gpt_update` → `pdfs_ref_check`). These are visual diffs of the compiled report, not source artifacts.
- `tmp/paper_2504_13837.pdf` is the original arXiv paper being read.
- `tmp/` is not tracked in the report build — it's a scratch area for paper processing and quality checks.

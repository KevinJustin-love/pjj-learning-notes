# 智能座舱

智能座舱（`Smart Cockpit`）可以分为以下部分。

![Smart Cockpit](C:\Users\pjj18\Desktop\note\IAV\pictures\smartCockpit.jpg)

有关智能座舱的具体讲解，可以参考。

https://www.bilibili.com/video/BV1xYD8YbEne/?spm_id_from=333.337.search-card.all.click&amp;vd_source=8d372b6a9cc7f61f68045441cb6490e4


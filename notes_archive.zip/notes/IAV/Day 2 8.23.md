# Day 2 8.23

## HMI

课题：**氛围模式** 帮用户放松

宠物模式？

在 `workshop` 中开展用户反馈的体验

结构化沟通 >> 代码

<img src="C:\Users\pjj18\Desktop\note\IAV\pictures\collaborate.jpg" style="zoom: 33%;" />

一份足够强大的 `spec` ，能很好的发挥 `llm` 的作用。开发项目时，需要一份很好的 `spec`

**未来应该如何做？**

- 理解软件开发
- 以产品经理或架构的角色

## LLM & 车载

预训练（掌握基本框架）—— SFT（理解人类） —— RLHF（学会人类偏好）

prompt 工程

### IAV Merida

eVTOL 交通识别, 使用 YOLO 模型识别潜在交通参与者
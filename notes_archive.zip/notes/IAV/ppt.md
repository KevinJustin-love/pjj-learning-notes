**优化结果、云端优势**

两个视频对比，同时播放

下面加标签



计时器 云端本地运行对比

<img src="C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20250824193113930.png" alt="image-20250824193113930" style="zoom:50;" />

+ 存在重复识别现象 :vs: 准确识别所有鸟类
+ 识别鸟类预测概率值低 :vs:  
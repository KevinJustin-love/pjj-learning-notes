# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build Commands

```bash
# Full build (requires XeLaTeX — Chinese support)
xelatex main.tex
biber main
xelatex main.tex
xelatex main.tex
```

Or use `latexmk` for one-shot build:
```bash
latexmk -xelatex main.tex
```

Clean build artifacts:
```bash
latexmk -C main.tex
# or manually: Remove-Item main.aux, main.bcf, main.log, main.out, main.synctex*, main.pdf
```

## Project Overview

This is a 数学建模 (Mathematical Modeling) final paper at USTC. Title: 数码相机定位 (Digital Camera Localization). The paper compares geometric (incremental SfM) and learning-based (VGGT) approaches for camera pose estimation and 3D reconstruction from multi-view images, with 3DGS as a downstream rendering-based validation backend. Experimental data: DTU dataset. The paper is substantially complete — abstract, all sections, results, and appendix are written.

## File Structure

- `main.tex` — single source file containing the entire paper (~1050 lines). No chapters or include files.
- `reference.bib` — BibLaTeX bibliography with 10 entries covering SfM, VGGT, 3DGS, and feature matching references.
- `elegantpaper.cls` — local document class (ElegantPaper v0.12, forked from GitHub). Provides `lang=cn`, `newtx` math font, BibLaTeX integration. Do not modify without strong reason.
- `image/` — all figures: pipeline diagrams, architecture diagrams, render results, logo, plus subdirectories `vggt_render/` and `viewer/` for per-scene render outputs.
- `elegantpaper-cn.tex` — example/template file from ElegantPaper; not part of the paper.

## Document Structure (main.tex)

The paper follows a standard 数模 paper layout:

1. **摘要** (Abstract) — written, summarizes the three-pillar framework and key experimental results.
2. **问题重述与建模思路** (§1) — problem restatement and modeling approach overview. Introduces the three-pillar structure: SfM (geometric), VGGT (learning-based), 3DGS (validation).
3. **模型假设与符号说明** (§2) — modeling assumptions for SfM, VGGT, and 3DGS. Unified symbol table.
4. **主模型：增量式 SfM** (§3) — core geometric pipeline: SIFT+RootSIFT matching, Scene Graph construction, two-view initialization, incremental registration (NBV + PnP), triangulation, BA (local + global).
5. **端到端前馈神经网络对照** (§4) — VGGT as learning-based comparison branch, plus VGGT+BA variant.
6. **下游验证：3DGS** (§5) — 3D Gaussian Splatting as rendering validation backend.
7. **实验设计** (§6) — experimental pipeline, branches (SfM / VGGT / VGGT+BA), ablation setup.
8. **实验结果** (§7) — results tables for camera registration, point cloud quality, ablation studies.
9. **结论** (§8)
10. **附录** — contains team member contributions (大作业分工).

## Key Conventions

- Chinese document: uses `ctex` via ElegantPaper's `lang=cn` option. Must compile with XeLaTeX.
- Bibliography: BibLaTeX with `biber` backend. Cite with `\cite{key}`.
- Math: `newtx` math font. Equation environment uses standard `equation`/`align`/`equation*`.
- Figures: `\includegraphics` with `width=0.92\linewidth` convention.
- Tables: `booktabs` + `tabular` with `\toprule`/`\midrule`/`\bottomrule`.
- Cross-references: standard `\ref{label}`, `\label{fig:...}`, `\label{tab:...}`, `\label{eq:...}`.
- The paper is substantially complete. All sections, figures, tables, and references are in place.
- When adding content, follow existing patterns for figure/table placement, equation formatting, and cross-referencing.
- Many commented-out symbol tables (§2) exist as reference; uncomment or adapt as needed rather than rewriting.

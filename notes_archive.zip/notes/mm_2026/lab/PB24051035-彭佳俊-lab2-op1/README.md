# 作业 2：基于 SVD 的图像压缩

> PB24051035 彭佳俊 | 中国科学技术大学 · 数学建模课程

本文档由 ai 生成 ---

## 项目简介

本项目实现了基于 **奇异值分解（SVD）** 的图像压缩系统，并与 **离散小波变换（DWT）** 和 **JPEG** 进行对比分析。系统包含自主实现的 SVD 算法（不调用库函数）、React + FastAPI 的交互式 Web GUI，以及 PSNR / SSIM / LPIPS 三层评价体系。

## 项目结构

```
PB24051035-彭佳俊-数学建模hw2/
├── backend/                    # Python 后端
│   ├── main.py                 # FastAPI 主服务（含 LPIPS 计算）
│   ├── svd_core.py             # 自主实现的 SVD 分解与图像压缩
│   ├── dwt_core.py             # 基于 PyWavelets 的 DWT 压缩
│   ├── generate_rd_curve.py    # RD 曲线生成脚本
│   ├── generate_jpeg_compare.py# JPEG 对比实验脚本
│   └── requirements.txt        # Python 依赖
├── frontend/                   # React 前端
│   ├── src/
│   │   ├── App.jsx             # 主应用组件
│   │   ├── index.css           # 全局样式（Glassmorphism 设计）
│   │   └── main.jsx            # 入口文件
│   ├── package.json
│   └── vite.config.js
├── report_compressed.pdf       # 实验报告，压缩后
└── README.md                   # 本文件
```

## 环境配置

### 后端

```bash
cd backend
conda activate mm26
pip install -r requirements.txt
```

主要依赖：FastAPI、NumPy、OpenCV、scikit-image、PyWavelets、PyTorch、lpips

### 前端

```bash
cd frontend
npm install
```

## 运行方式

### 1. 启动后端

```bash
cd backend
conda activate mm26
uvicorn main:app --reload
```

后端将在 `http://localhost:8000` 启动。首次启动时会自动加载 LPIPS 模型（AlexNet 权重），请确保网络可用或权重已缓存。

### 2. 启动前端

```bash
cd frontend
npm run dev
```

前端将在 `http://localhost:5173` 启动，在浏览器中打开即可使用。

### 3. 使用 GUI

1. 在左侧边栏选择算法（SVD / DWT / GAN）
2. 上传图片，调整参数（SVD 的 k 值、DWT 的小波基类型等）
3. 点击 **Run Compression** 执行压缩
4. 查看对比滑块、PSNR / SSIM / LPIPS / CR 指标
5. 点击 **Download Compressed** 下载压缩结果

### 4. 生成实验图表（可选）

```bash
cd backend
conda activate mm26

# 生成 SVD vs DWT 的 RD 曲线
python generate_rd_curve.py

# 生成 JPEG 对比实验数据与图表
python generate_jpeg_compare.py
```

## 核心算法

- **SVD**：基于 $A^TA$（或 $AA^T$）的特征值分解自主实现，选择较小维度以降低复杂度
- **DWT**：基于 PyWavelets 的多级小波分解 + 硬阈值截断（保留 LL 低频子带不变）
- **评价指标**：像素级（PSNR）→ 结构级（SSIM）→ 感知级（LPIPS，AlexNet backbone）

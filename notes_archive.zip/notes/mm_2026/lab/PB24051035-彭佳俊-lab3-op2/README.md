# 实验三：使用神经网络进行昆虫分类

姓名：彭佳俊
学号：PB24051035

本项目为《数学建模》课程的实验三（选项2）提交内容，主要使用多层感知机（MLP）对带有纯净标签和噪声标签的昆虫特征数据集进行三分类实验，并进行了系统的消融与鲁棒性分析。

## 📁 目录结构说明

```text
PB24051035-彭佳俊-lab3-op2/
├── report.pdf                 # 实验报告（包含正文的分类与消融实验，及附录的数据集去噪分析）
├── requirements.txt           # Python 运行环境的依赖库配置文件
└── src/                       # 源代码目录
    ├── insect_classification.py       # 核心分类实验主程序（包含训练、测试、消融实验以及结果可视化功能）
    ├── fix_dataset2.py                # 数据集 2 标签噪声修正脚本（根据 Ground Truth 还原正确标签并生成数据集 3）
    └── run_dataset3_experiment.py     # 数据集 3 的对比验证脚本（用于生成附录 A 中的对比图表和评估结果）
```

## 🛠️ 环境配置

本项目主要依赖 `PyTorch` 深度学习框架及相关的科学计算与绘图库。
请确保本地环境安装了 Python 3.8+，然后使用以下命令安装所有必需的第三方库：

```bash
pip install -r requirements.txt
```

## 🚀 运行说明

**请在运行代码前，在 `src` 目录下新建 `insects` 文件夹，并将原始数据集文件（`insects-training.txt`, `insects-testing.txt`, `insects-2-training.txt`, `insects-2-testing.txt`）放入该文件夹中：`src/insects/`。（由于数据集为官方提供，提交时未包含数据集文件夹）。**

### 1. 运行核心分类与消融实验

若要复现实验报告正文部分的结果（消融实验表格、决策边界图、混淆矩阵、Loss 曲线等），请运行：

```bash
python src/insect_classification.py
```
> **注意**：该脚本执行耗时可能较长，因为它将遍历 12 种配置，在两个数据集上分别训练 500 个 Epoch，并在 `results/` 目录下生成一系列高清图表。

### 2. 运行数据集去噪与对比实验（附录部分）

若要复现报告附录 A 中对数据集 2 的噪声修正和验证过程：

- **第一步：修复数据集**
  运行修正脚本，它会分析噪声情况并生成纯净的“数据集 3”：
  ```bash
  python src/fix_dataset2.py
  ```

- **第二步：进行对比实验**
  使用最优配置（MediumNet + LeakyReLU）在三个数据集上重新训练，并生成对比图表：
  ```bash
  python src/run_dataset3_experiment.py
  ```

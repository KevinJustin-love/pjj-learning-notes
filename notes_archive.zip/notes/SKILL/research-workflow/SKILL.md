# Research-Workflow

参考：

> 一分钟版工作流，方便收藏： 1️⃣ AGENTS.md：项目总纲，每个新开的 Agent 先读它 2️⃣ related_work/：让 Agent 检索下载文献，PDF 和 LaTeX 源码都下——泛读用 PDF，查表格公式用 LaTeX 3️⃣ 复现/：先复现几篇重要文章再找 idea，问题往往藏在复现里 4️⃣ brainstorm.md：和 Agent 把问题、假设、方法聊出来 5️⃣ experiment/：results.md 记每一版结果，evaluation.md 把测评标准写死 6️⃣ DataSet/：下数据处理数据全交给 Agent，挂 loop 命令让它自己盯

我是一个刚接触 xxx 领域 / 项目的初学者，我需要你按照如下方式初始化当前的科研工作流，按照如下方式操作：

1. 在当前目录创建 Related-work/ folder，里面存放该领域的相关文献，使用 deepxiv skill，用于检索文献。其中，每一个新的论文使用一个文件夹存放。这个文件夹中可以包含该论文的 paper.pdf / Latex 源码文件夹(从 arxiv 获取)。pdf 文件用于粗略阅读文献，LaTex 负责更细粒度地阅读。 
2. 创建一个 复现/ folder，需要 agent 从 Related-work 文件夹中挑选几篇最重要的用来复现，同样给每篇论文创建子文件夹

3. 创建 brainstorm.md，记录我基于 Related-work 以及 复现 得到的结果发现问题，提出 idea
4. 创建 experiments/ folder，来写实验代码。注意，agent 写完实验代码后，需要提醒我进行人工 verify，不允许直接运行代码等。另外，本文件夹下要放 results.md，让 agent 把每一版的方法都命名清楚，做好结果的总结。为了评估，需要创建 evaluation.md，写明用什么数据训练，用什么数据测试，用什么 metrics，要做哪些可视化。
5. 创建 datasets/ folder 存放数据集，放 datasets.md，里面包含有什么数据，怎么处理的，命名方式等，给 agent 查看。对于下数据，使用 loop 命令
6. prompt.md，用于切换 agent 窗口的。当一个 agent 做完一个想法后，让他写入现在的实验进度，下一步要做什么，让下一个 agent 能接上的 prompt 
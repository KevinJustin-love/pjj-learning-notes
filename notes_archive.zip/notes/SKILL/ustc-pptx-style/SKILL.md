---
name: ustc-pptx-style
description: USTC-blue visual style toolkit for single-page editable PPTX slides. Provides reusable primitives (blue title bar with logo, colored category pills, tinted background panels, light-blue observation footer, group-tinted tables, ✓/✗/学术 status markers) that can be composed into ANY one-slide layout — surveys, comparisons, taxonomies, timelines, dashboards. Output is native PPT (editable, vector, ~30-60 KB). Use when user wants a "好看的一页 PPT", "USTC 风格 slide", "可编辑 PPTX", "把这个做成一页 slide", or any single-slide content needing a polished, info-dense academic look.
---

# USTC PPTX 风格工具箱

把"深蓝顶栏 + 彩色胶囊 + tint 分组 + 浅蓝观察栏 + ✓/✗/学术 配色"这套\hl{视觉风格}做成可组合的 PPT 原语。
任何单页内容——调研表、方法对比、谱系树、时间线、产品 landscape——都能用这套积木拼。

## 风格元素（7 类积木）

| 元素 | 函数 | 视觉效果 |
|---|---|---|
| **封面页** | `add_cover_slide(prs, title, ...)` | 包含校徽、大标题、副标题与个人学号信息的优雅封面 |
| **结语页** | `add_ending_slide(prs, ...)` | 居中蓝色框，"Thank You" + 答辩提问 + 个人署名 |
| **深蓝顶栏** | `add_title_bar(slide, title, logo_path)` | 全宽 USTC 蓝色条，白色大标题 + 右上角校徽 |
| **彩色胶囊** | `add_pill(...)` / `add_pill_row(...)` | 5 色（蓝/橙/绿/紫/红）圆角胶囊，白字加粗 |
| **tint 面板** | `add_panel(slide, x, y, w, h, tint, title, body)` | 5 色浅底背景方块，可配同色标题 + 正文 |
| **观察栏** | `add_observation_footer(slide, notes)` | 浅蓝底信息盒，蓝粗"观察:"+ 多条小结 |
| **分组表** | `add_grouped_table(slide, ..., rows=[(key, vals)])` | 原生 PPT 表格，按 key 分组染 tint，✓/✗/学术 自动着色 |

5 个分类用 key `"A"`..`"E"` 表示，**胶囊色 + tint 色 + 表格行色一一对应**：

| key | 胶囊 / 强调 | tint |
|---|---|---|
| A | `#1E88E5` 蓝 | `#E3F2FD` |
| B | `#F4511E` 橙 | `#FFF3E0` |
| C | `#43A047` 绿 | `#E8F5E9` |
| D | `#8E24AA` 紫 | `#F3E5F5` |
| E | `#E53935` 红 | `#FFEBEE` |

主色 USTC Blue `#003F88`（顶栏 / 表头 / 强调字），浅色 `#E1EBFA`（观察栏底）。

## 何时使用

- 用户希望 \textbf{"做成可编辑 PPT"}（区别于把 LaTeX PDF 转图片版 PPT）
- 用户要做 \textbf{单页 slide}：调研、对比、谱系、时间线、方案对比、风险矩阵、特性卡片……
- 用户说 \textbf{"做成 skills"}/\textbf{"复用这种风格"}/\textbf{"换个 slide 用同样风格"}

## 资源文件

```
skills/ustc-pptx-style/resources/
├── ustc_style.py             # ← 核心：风格原语库
├── figures/
│   └── logo.png              # USTC 校徽 (600px)
└── examples/
    ├── example_survey.py     # 调研表 (顶栏 + 胶囊行 + 大表 + 观察栏)
    ├── example_compare.py    # 双栏对比 (顶栏 + 2 个 tint panel + 观察栏)
    └── example_taxonomy.py   # 谱系五栏 (顶栏 + 5 个 tint panel + 观察栏)
```

## 使用步骤（AI 自动执行）

### Step 1: 复制风格库 + logo 到工作目录

```bash
SKILL_DIR="<this skill's absolute directory path>"
TARGET_DIR="<user workspace>/presentation"

mkdir -p "$TARGET_DIR/figures"
cp "$SKILL_DIR/resources/ustc_style.py"       "$TARGET_DIR/"
cp "$SKILL_DIR/resources/figures/logo.png"    "$TARGET_DIR/figures/"
```

### Step 2: 确保 Python 环境有 python-pptx

```bash
cd "$TARGET_DIR"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/pip install --quiet python-pptx Pillow
```

### Step 3: 选一个 example 作为骨架，或现写

根据用户要求选一个最近的布局复制到工作目录改：

| 场景 | 起点 example |
|---|---|
| 多行对比表 / 调研横向比较 | `example_survey.py` |
| A vs B 两栏深度对比 | `example_compare.py` |
| 3–5 类并列谱系/landscape | `example_taxonomy.py` |
| 其他自由布局 | 从 ustc_style import 自由组合 |

### Step 4: 编辑骨架文件，替换内容；运行；打开

```bash
cd "$TARGET_DIR"
.venv/bin/python my_slide.py main.pptx
open main.pptx
```

## 风格原语 API 速查

```python
from ustc_style import (
    new_presentation,            # 新建 16:9 空 PPTX (13.33" × 7.5")
    add_cover_slide,             # 新建并添加封面页
    add_ending_slide,            # 新建并添加结语页
    add_title_bar,               # 顶部蓝条 + 标题 + (可选)logo
    add_pill, add_pill_row,      # 胶囊单个 / 一行带前缀
    add_panel,                   # tint 浅底面板（带边框）
    add_observation_footer,      # 浅蓝观察栏（底部）
    add_grouped_table,           # 分组染色表格 (rows = [(key, [vals])])
    add_text_block,              # 自由文本块（多 run 多段）
    mark_color,                  # 取 ✓/✗/学术 对应颜色
    KEYS, PILL, TINT,            # "A".."E" + 颜色字典
    USTC_BLUE, USTC_LIGHT,       # 主色
    WHITE, DARK,                 # 通用色
    CHINESE_FONT,                # "Microsoft YaHei"
)
```

### add_title_bar
```python
add_title_bar(slide, title="标题", logo_path="figures/logo.png",
              height="0.55in", font_size=22)
```

### add_pill_row
```python
add_pill_row(slide,
    pills=[("分类A", "A"), ("分类B", "B"), ...],
    label_prefix="维度: ",                  # 蓝色加粗前缀
    left_text="国家 · 年份 · 算法",          # 灰色描述
    y="0.68in", pill_start_x="5.7in")
```

### add_panel
```python
add_panel(slide, x="0.3in", y="0.9in", w="6in", h="3in",
          tint="A",                          # 选 "A".."E"
          title="原理",                       # 同色加粗大标题
          body="正文……",                     # 普通段落
          title_size=12, body_size=10,
          border=True)
```

### add_grouped_table
```python
add_grouped_table(slide,
    x="0.25in", y="1.05in", w="12.83in", h="5.55in",
    headers=["求解器", "国家", "年份", ...],
    rows=[                                   # 每行 = (key, [每列值])
        ("A", ["IPOPT", "美国", "2002", ...]),
        ("B", ["BARON", "美国", "1996", ...]),
    ],
    col_pct=[0.10, 0.07, 0.06, ...],         # 列宽比例，必须 sum = 1.0
    center_cols=[1, 2, 4, 5],                # 居中列
    mark_cols=[4, 5],                        # ✓/✗/学术 着色列
    header_size=10, body_size=9)
```

### add_observation_footer
```python
add_observation_footer(slide,
    label="观察: ",
    notes=["(1) ...", "(2) ...", "(3) ..."],
    y="6.65in", h="0.65in")

### add_cover_slide
```python
add_cover_slide(prs,
    title="我的演示文稿标题",
    subtitle="副标题（可选）",
    author="彭佳俊",
    student_id="PB24051035",
    department="人工智能与数据科学学院",
    logo_path="figures/logo.png")
```

### add_ending_slide
```python
add_ending_slide(prs,
    title="Thank You",
    subtitle="欢迎提问与讨论 (Q&A)",
    author="彭佳俊",
    department="人工智能与数据科学学院",
    logo_path="figures/logo.png")
```
```

## 布局约定（默认坐标）

16:9 默认尺寸 \textbf{13.33in × 7.5in}，惯用区域划分：

```
0          ┌─────────────────────────────────────────┐
           │ TITLE BAR (full-width, 0.55in)          │
0.55       ├─────────────────────────────────────────┤
           │ pill row + dimension text  (0.30in)     │
1.00       ├─────────────────────────────────────────┤
           │                                         │
           │ MAIN CONTENT AREA                       │
           │ (panels / table / diagram, ~5.55in)     │
           │                                         │
6.55       ├─────────────────────────────────────────┤
6.65       │ OBSERVATION FOOTER  (0.65in)            │
7.30       └─────────────────────────────────────────┘
7.50
```

留 0.25–0.3 in 左右边距即可。

## 注意事项

1. \textbf{中文字体}：默认 Microsoft YaHei（跨平台兼容），可在调用 `add_run` 时换 `font=`。
2. \textbf{logo 路径}：脚本同目录下的 `figures/logo.png`；缺失会跳过不报错。
3. \textbf{表格行数}：建议 15–25 行；< 8 行会显得空旷，> 25 行需要减小 row 高/字号。
4. \textbf{颜色不要乱改}：5 个 key + 主色已是经过调和的视觉规范；如必须自定义，可直接修改 `PILL`/`TINT` 字典。
5. \textbf{原生可编辑}：输出 30–60 KB；打开后表格、文本框、形状全部可在 PPT 里编辑。
6. \textbf{16:9 only}：所有 example 都按 13.33×7.5 in 排版；改 4:3 需调整 panel 宽度。

---
name: ustc-report
description: 使用中国科学技术大学模板创建 LaTeX 实验报告 / 课程论文
---

# USTC Report 模板 Skill

## 概述

中国科学技术大学 LaTeX 实验报告模板，适用于课程作业、实验报告、课程论文等学术文档。带有 USTC Logo 封面页、精美摘要框、Terminal 风格代码块、实验结果展示框等实用组件。

## 何时使用

当用户要求：
- 写实验报告 / 课程论文 / 课程作业 / lab report
- 使用中国科学技术大学模板写报告
- 用 LaTeX 写学术报告

## 资源文件位置

模板资源存放在本 skill 目录：

```
skills/ustc-report/
├── SKILL.md        # 本文件
└── logo.jpg        # USTC 校名+校徽 Logo 图片
```

## 使用步骤（全自动，AI 必须自行完成以下所有步骤）

> **重要**：以下所有步骤必须由 AI agent 自动执行，用户不需要手动复制任何文件。
> `SKILL_DIR` 指本 SKILL.md 所在目录的绝对路径。
> `TARGET_DIR` 默认为 `SKILL_DIR/report/`（即本 skill 目录下的 `report/` 子目录），用户可指定其他路径。

### Step 1: 自动创建目录并复制模板资源（必须用 run_command 执行）

// turbo
```bash
SKILL_DIR="<this skill's absolute directory path>"
TARGET_DIR="$SKILL_DIR/report"

mkdir -p "$TARGET_DIR/img"
cp "$SKILL_DIR/logo.jpg" "$TARGET_DIR/"
```

**注意**：
- AI 需要自动推算 `SKILL_DIR` 的绝对路径（即 SKILL.md 所在目录），不要让用户手动操作。
- `logo.jpg` 放在 `TARGET_DIR/` 根目录下（与 `.tex` 同级）。
- 所有其他图片（实验结果图等）放在 `TARGET_DIR/img/` 文件夹。

### Step 2: 生成 main.tex（使用 write_to_file 工具）

根据用户提供的内容，基于下面的模板骨架生成 `main.tex`，写入 `TARGET_DIR/main.tex`。

```latex
\documentclass[12pt, oneside, a4paper]{ctexart}
\renewcommand{\contentsname}{目录}
\renewcommand{\tablename}{表}
\usepackage{graphicx} 
\usepackage{hyperref} 
\hypersetup{
    colorlinks=true,    
    linkcolor=blue,    
    filecolor=magenta,  
    urlcolor=cyan,      
    citecolor=blue,     
    pdfpagelabels=false 
}
\usepackage{amsmath}
\usepackage{amssymb}
\usepackage{anyfontsize}
\usepackage[table]{xcolor}  
\usepackage{geometry}
\usepackage{tcolorbox}
\tcbuselibrary{skins}
\usepackage{tikz} 
\usepackage{multirow}
\usetikzlibrary{calc}
\usepackage{siunitx}
\usepackage{caption}
\usepackage{placeins}
\usepackage{float}   
\renewcommand{\figurename}{图}
\renewcommand{\refname}{参考文献}
\usepackage{tabularx}
\usepackage{enumitem}
\usepackage{array}
\usepackage{booktabs}
\usepackage{makecell}
\usepackage{adjustbox}
\usepackage{listings}
\usepackage{subcaption}
\geometry{left=2.5cm,right=2.5cm,top=2.5cm,bottom=2.5cm}

% ══════════════════════════════════════════════════════════════
% 摘要区域配色
% ══════════════════════════════════════════════════════════════
\definecolor{absBlue}{HTML}{0F4C81}
\definecolor{absLight}{HTML}{EAF4FF}
\definecolor{absAccent}{HTML}{00A896}

% ══════════════════════════════════════════════════════════════
% Terminal 风格（深色）—— 用于代码/网络结构展示
% ══════════════════════════════════════════════════════════════
\definecolor{termbg}{RGB}{40, 44, 52}
\definecolor{reddot}{RGB}{255, 95, 86}
\definecolor{yellowdot}{RGB}{255, 189, 46}
\definecolor{greendot}{RGB}{39, 201, 63}
\definecolor{codeblue}{RGB}{97, 175, 239}
\definecolor{codegreen}{RGB}{152, 195, 121}
\definecolor{codegray}{RGB}{171, 178, 191}
\definecolor{codeyellow}{RGB}{229, 192, 123}

\newtcolorbox{terminal}{
  colback=termbg,
  colframe=termbg,
  arc=8pt,
  boxrule=0pt,
  leftupper=10pt,
  rightupper=10pt,
  top=8pt,
  bottom=10pt,
}

\newcommand{\termline}[2]{%
  {\color{codeblue}\small #1}\hspace{10pt}{\color{white}\ttfamily\small #2}\\[2pt]%
}
\newcommand{\termtext}[1]{%
  {\color{codegray}\ttfamily\small #1}\\[2pt]%
}
\newcommand{\termhl}[1]{%
  {\color{codegreen}\ttfamily\small\bfseries #1}\\[2pt]%
}

% ══════════════════════════════════════════════════════════════
% Expbox 风格 —— 用于实验运行结果展示
% ══════════════════════════════════════════════════════════════
\definecolor{topbarbg}{RGB}{245,244,241}
\definecolor{bodybg}{RGB}{255,255,255}
\definecolor{border}{RGB}{210,208,202}
\definecolor{keyblue}{RGB}{56,142,220}
\definecolor{valgreen}{RGB}{25,180,50}
\definecolor{dimgray}{RGB}{160,158,150}
\definecolor{passgn}{RGB}{22,160,44}
\definecolor{passbg}{RGB}{220,248,224}

\tcbset{
  expbox/.style={
    enhanced,
    arc=8pt,
    boxrule=0.4pt,
    colframe=border,
    colback=bodybg,
    left=14pt, right=14pt,
    top=0pt, bottom=0pt,
    attach title to upper,
    title={%
      \begin{tikzpicture}[baseline=-1pt]
        \fill[passgn,rounded corners=2pt] (0,0) rectangle (0.32,0.32);
        \draw[white,line width=0.7pt,line cap=round,line join=round]
          (0.06,0.16) -- (0.14,0.24) -- (0.26,0.08);
      \end{tikzpicture}\hspace{6pt}%
      {\footnotesize\sffamily\color{dimgray}##1}%
      \hfill
      \colorbox{passbg}{%
        \textcolor{passgn}{\bfseries\fontsize{7}{8}\selectfont PASSED}%
      }%
    },
    coltitle=black,
    toptitle=8pt,
    bottomtitle=6pt,
    fonttitle=\small,
    borderline north={0.4pt}{0pt}{border},
  },
}

\newcommand{\exprow}[3]{%
  {\color{dimgray}#1}\hspace{10pt}%
  {\ttfamily\color{keyblue}#2}%
  {\color{dimgray}\ :\ }%
  {\ttfamily #3}\\[1pt]%
}
\newcommand{\expsep}{%
  \vspace{2pt}%
  {\color{border}\hrule height 0.4pt}\vspace{6pt}%
}

% ══════════════════════════════════════════════════════════════
% 消融实验表格辅助命令
% ══════════════════════════════════════════════════════════════
\definecolor{rowblue}{RGB}{219,234,248}
\definecolor{upgreen}{RGB}{52,138,78}
\definecolor{downred}{RGB}{200,50,50}
\definecolor{basegray}{RGB}{160,160,160}
\definecolor{groupgray}{RGB}{100,100,100}
\definecolor{colvline}{RGB}{200,200,200}

\newcommand{\up}[1]{{\color{upgreen}\small$\uparrow$\,#1}}
\newcommand{\dn}[1]{{\color{downred}\small$\downarrow$\,#1}}
\newcommand{\baseline}{{\color{basegray}\small\itshape Baseline}}
\newcommand{\dash}{{\color{dimgray}---}}
\newcommand{\grouprow}[2]{%
  \midrule[\lightrulewidth]
  \multicolumn{#1}{c}{{\color{groupgray}\scriptsize\ttfamily #2}} \\[-2pt]
  \midrule[\lightrulewidth]
}

% ══════════════════════════════════════════════════════════════
% listings 代码高亮配置
% ══════════════════════════════════════════════════════════════
\lstset{
    basicstyle=\ttfamily\small,
    breaklines=true,
    keywordstyle=\bfseries\color{codeblue},
    commentstyle=\itshape\color{codegray},
    stringstyle=\color{codegreen},
    numbers=left,
    numberstyle=\tiny\color{dimgray},
    frame=single,
    rulecolor=\color{border},
    backgroundcolor=\color{bodybg},
    showstringspaces=false,
    tabsize=4,
}

\begin{document}

% ══════════════════════════════════════════════════════════════
% 标题页
% ══════════════════════════════════════════════════════════════
\begin{titlepage}
    \centering
    \includegraphics[width=0.5\textwidth]{logo.jpg}\\ 
    \vspace{2cm} 
  {\huge \bfseries 报告标题}\\[0.6cm]
  {\Large \bfseries 课程名称--labN}\\[1.5cm] 
    {\large 指导老师: 教师姓名}\\[1cm] 
    {\large PBxxxxxxxx 学生姓名}\\[1cm] 
    {\large 学院名称}\\[1cm] 
    {\large \today} 
\end{titlepage}

% ══════════════════════════════════════════════════════════════
% 目录
% ══════════════════════════════════════════════════════════════
{\hypersetup{linkcolor=black}%
\fontsize{14pt}{20pt}\selectfont
\tableofcontents}

\clearpage
\noindent
\vspace{1em}

% ══════════════════════════════════════════════════════════════
% 摘要
% ══════════════════════════════════════════════════════════════
\begin{tcolorbox}[
  enhanced,
  colback=absLight,
  colframe=absBlue,
  boxrule=0.9pt,
  arc=2mm,
  left=12pt,
  right=12pt,
  top=14pt,
  bottom=12pt,
  borderline west={2.5pt}{0pt}{absAccent},
  drop fuzzy shadow=black!15,
  fonttitle=\heiti\bfseries\large,
  title=摘\hspace{1em}要,
  coltitle=white,
  attach boxed title to top left={xshift=10pt,yshift=-\tcboxedtitleheight/2},
  boxed title style={
    colback=absBlue,
    colframe=absBlue,
    boxrule=0pt,
    arc=1.5mm,
    left=8pt,
    right=8pt,
    top=4pt,
    bottom=4pt
  }
]
\setlength{\parindent}{2em}
\normalsize

在此填写摘要内容。

\vspace{0.8em}
\noindent{\heiti\color{absBlue}关键词：} 关键词1，关键词2，关键词3
\end{tcolorbox}

% === 以下根据用户内容生成 \section / \subsection ===

\section{引言 (Introduction)}

在此填写引言内容。

\section{实验设置 (Experimental Setup)}

\subsection{数据与预处理}

\subsection{模型架构}

\subsection{训练配置}

\section{实验结果 (Results)}

\section{分析与讨论 (Discussion)}

\section{结论 (Conclusion)}

% ══════════════════════════════════════════════════════════════
% 参考文献
% ══════════════════════════════════════════════════════════════

\begin{thebibliography}{9}
\bibitem{ref1}
作者. 标题[J]. 期刊, 年份.
\end{thebibliography}

\end{document}
```

**内容生成注意事项**:

1. **标题页信息**：根据用户提供的标题、课程名、教师、学号姓名、学院填写
2. **图片引用**：所有实验结果图片使用 `\IfFileExists{img/xxx.png}{...}{}` 包裹，避免缺图时编译报错
3. **摘要内容**：根据用户的实验内容自动生成
4. **章节结构**：根据报告类型灵活调整（实验报告推荐：引言→实验设置→结果→讨论→结论）

### Step 3: 自动编译（必须用 run_command 执行）

// turbo
```bash
cd "$TARGET_DIR"
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex
```

必须使用 **XeLaTeX**（不能用 pdflatex），编译两次确保目录和交叉引用正确。

### Step 4: 自动打开预览

// turbo
```bash
open "$TARGET_DIR/main.pdf"
```

## 常用 LaTeX 报告语法速查

### 插入图片

```latex
% 图片放入 img/ 文件夹
\IfFileExists{img/result.png}{
\begin{figure}[H]
  \centering
  \includegraphics[width=0.80\textwidth]{img/result.png}
  \caption{图片描述}
  \label{fig:result}
\end{figure}
}{}
```

### 并排图片

```latex
\begin{figure}[H]
  \centering
  \begin{subfigure}{0.48\textwidth}
    \includegraphics[width=\linewidth]{img/fig_a.png}
    \caption{子图A}
  \end{subfigure}
  \hfill
  \begin{subfigure}{0.48\textwidth}
    \includegraphics[width=\linewidth]{img/fig_b.png}
    \caption{子图B}
  \end{subfigure}
  \caption{总标题}
\end{figure}
```

### 学术表格

```latex
\begin{table}[H]
\centering
\caption{实验结果对比}
\begin{tabular}{lcc}
    \toprule
    \textbf{方法} & \textbf{Accuracy} & \textbf{F1 Score} \\
    \midrule
    Baseline & 0.8500 & 0.8400 \\
    Ours     & \textbf{0.9200} & \textbf{0.9100} \\
    \bottomrule
\end{tabular}
\label{tab:results}
\end{table}
```

### 消融实验表格（带升降标记）

```latex
\up{1.5\%}     % 绿色 ↑1.5%
\dn{0.3\%}     % 红色 ↓0.3%
\baseline      % 灰色斜体 Baseline
\dash          % 灰色 ---
\rowcolor{rowblue}  % 蓝色高亮 Baseline 行
\grouprow{4}{分组名称}  % 分组分隔行
```

### 精美摘要框

```latex
\begin{tcolorbox}[
  enhanced, colback=absLight, colframe=absBlue,
  boxrule=0.9pt, arc=2mm,
  borderline west={2.5pt}{0pt}{absAccent},
  drop fuzzy shadow=black!15,
  fonttitle=\heiti\bfseries\large,
  title=摘\hspace{1em}要, coltitle=white,
  attach boxed title to top left={xshift=10pt,yshift=-\tcboxedtitleheight/2},
  boxed title style={colback=absBlue, colframe=absBlue, arc=1.5mm}
]
摘要内容...

\noindent{\heiti\color{absBlue}关键词：} 关键词列表
\end{tcolorbox}
```

### Terminal 风格代码块

```latex
\begin{terminal}
\termtext{模型结构:}
\termline{Layer}{Conv2d(1, 32, 3x3)}
\termhl{Total params: 421,642}
\end{terminal}
```

### 实验结果展示框（Expbox）

```latex
\begin{tcolorbox}[expbox={实验名称}]
\exprow{📊}{accuracy}{0.9178}
\exprow{📊}{loss}{0.2438}
\expsep
\exprow{⏱}{time}{12.34s}
\end{tcolorbox}
```

### 代码高亮（listings）

```latex
\begin{lstlisting}[language=Python, caption={训练代码}]
for epoch in range(num_epochs):
    model.train()
    for batch in train_loader:
        optimizer.zero_grad()
        loss = criterion(model(batch), labels)
        loss.backward()
        optimizer.step()
\end{lstlisting}
```

### 数学公式

```latex
% 行内公式
$E = mc^2$

% 独立公式（带编号）
\begin{equation}
    L = -\sum_{i=1}^{N} y_i \log(\hat{y}_i)
    \label{eq:cross-entropy}
\end{equation}

% 多行对齐公式
\begin{align}
    \text{Accuracy} &= \frac{TP + TN}{TP + TN + FP + FN} \\
    \text{Precision} &= \frac{TP}{TP + FP}
\end{align}
```

### 交叉引用

```latex
如图\ref{fig:result}所示...
如表\ref{tab:results}所示...
由公式\ref{eq:cross-entropy}可知...
```

## 注意事项

1. **编译器**: 必须用 `xelatex`，不能用 `pdflatex`（因为使用 `ctexart` 中文支持）
2. **图片路径**: `logo.jpg` 放在 tex 同目录，其他图片放在 `img/` 子目录
3. **图片容错**: 使用 `\IfFileExists{img/xxx.png}{...}{}` 包裹图片引用，缺图时不报错
4. **中英文混排**: `ctexart` 文档类已内置中文支持，可直接混排
5. **浮动体位置**: 推荐使用 `[H]`（需 `float` 宏包）强制在当前位置放置图表
6. **编译两次**: 第一次生成辅助文件，第二次解析交叉引用和目录

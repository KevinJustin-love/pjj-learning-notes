# USTC Report Skill 🎓

> 中国科学技术大学 LaTeX 实验报告模板，封装为 **AI Agent 可自动调用的 Skill**。
>
> 只需一句话描述你的实验内容，AI 自动生成完整的 LaTeX 报告。

## ✨ 特性

- 🏫 **USTC 封面页**（Logo + 标题 + 学号信息）
- 📋 **精美摘要框**（带蓝色边框 + 阴影 + 关键词标签）
- 💻 **Terminal 风格代码块**（深色主题，适合展示模型结构）
- 📊 **实验结果展示框**（Expbox，带 ✓PASSED 标记）
- 📈 **消融实验表格**（带 ↑↓ 升降标记、蓝色高亮行、分组标题）
- 🔤 **中英文混排**（ctexart，开箱即用）
- 🤖 **AI Skill 全自动**：读取 `SKILL.md` 后自动生成完整报告

## 📁 文件结构

```
ustc-report/
├── README.md        # 本文件
├── SKILL.md         # AI Agent 自动化使用指南 + LaTeX 语法速查
├── logo.jpg         # USTC 校名+校徽 Logo
└── report/          # 生成的报告目录（由 AI 自动创建）
    ├── main.tex     # LaTeX 源文件
    ├── main.pdf     # 编译输出
    ├── logo.jpg     # USTC Logo（自动复制）
    └── img/         # 实验图片目录
        └── ...
```

## 🚀 快速开始

### 方式 A：作为 AI Skill 使用（推荐）

只需对 AI Agent 说：

> "用科大报告模板写一份关于 XXX 的实验报告"

AI 会自动完成所有步骤。

### 方式 B：手动使用

1. 复制 `logo.jpg` 到报告目录
2. 新建 `img/` 子目录放置实验图片
3. 编写 `main.tex`（参考 SKILL.md 中的模板骨架）
4. 使用 XeLaTeX 编译两次

> ⚠️ **必须使用 XeLaTeX 编译**，不支持 pdfLaTeX。

## 📄 许可证

MIT License

---

**Made with ❤️ for USTC students and researchers.**

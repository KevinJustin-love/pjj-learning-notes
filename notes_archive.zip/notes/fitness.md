# 健身

参考文档：[💪🏻B站版《健身新手的训练完全手册》™_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1Hk4y187jF/?)

健身分为 五分化、四分化、三分化、二分化 等方法。其中会借鉴肌肉的协同作用

## 三分化

Day 1: 背；肩后束；肱二头

Day 2: 胸；肩前中束；肱三头

Day 3: 腿；腹

### 协同肌群1 胸；肩前中束；肱三头

<img src="C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905135804668.png" alt="image-20260905135804668" style="zoom:50%;" />

注意，这只是协同训练，三个部位的肌肉还需要补训：

<img src="C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905140033781.png" alt="image-20260905140033781" style="zoom:50%;" />

### 协同肌群2 背；肩后束

同理

<img src="C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905140256608.png" alt="image-20260905140256608" style="zoom:50%;" />

上背划船更能练到肩后束

### 动作模式

![image-20260905140946978](C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905140946978.png)

### 训练计划

![image-20260905141311905](C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905141311905.png)

三个动作可以随意交换，但推荐练背再练胸之前

有关动作的难易：

![image-20260905141836917](C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905141836917.png)

---

---

![image-20260905142943888](C:\Users\pjj18\AppData\Roaming\Typora\typora-user-images\image-20260905142943888.png)

RM 指的是 Repetition Maximum，即：用某个重量，在动作标准不借力的情况下，你拼尽全力能完成的最多次数
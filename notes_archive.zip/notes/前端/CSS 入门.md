# CSS 入门

**CSS：** `Cascading Style Sheets` 。中文是 `层叠样式表` 。

用于定义网页样式和布局的样式表语言。

## CSS 语法

CSS 通常由选择器、属性和属性值组成，多个规则可以组合在一起，以便同时应用多个样式。

```css
选择器 {
    属性1: 属性值1;
    属性2: 属性值2;
}
```

下面是一个 p 标签的选择器。

```css
p {
    color: blue;
    font-size: 16px;
}
```

## CSS 三种导入方式

1. `内联样式（Inline Style）`
2. `内部样式表（Internal Stylesheet）`
3. `外部样式表（External Stylesheet）`

三种导入方式的优先级： `内联样式 > 内部样式表 > 外部样式表`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSS trial</title>
    <link rel="stylesheet" href="./style.css">  <!-- 使用外部样式表需说明链接 -->

    <style>
        p {
            color: blue;
            font-size: 16px;
        }                               <!-- 内部样式表需在 head 中定义 -->
    </style>
</head>
<body>
    <p>这是一个应用了css样式的文本。</p>
    <h1 style="color:red;">这是一个使用内联样式的一级标题标签。</h1>
    <h2>这是一个使用外部样式表的三级标题。</h2>
</body>
</html>
```

其中，`style.css` 文件的内容如下。

```css
h2 {
    color: purple;
}
```

## 选择器

```css
/* 这是一个选择器实例 */
p {
	color: blue;
    font-size: 16px;
}
```

选择器包括以下形式：

+ 元素选择器
+ 类选择器
+ ID 选择器
+ 通用选择器
+ 子元素选择器
+ 后代选择器（包含选择器）
+ 并集选择器（兄弟选择器）
+ 伪类选择器

```css
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selector</title>
    <style>
        /* 元素选择器 */
        h1 {
            color: cadetblue;
        }

        /* 类选择器 */
        .highlight {
            background-color: chocolate;
        }

        /* ID 选择器 */
        #header {
            font-size: 30px;
        }

        /* 通用选择器 */
        * {
            font-family: 'KaiTi';  
            font-weight: 400;
        }

        /* 子元素选择器 只影响与父代直接联系的子元素，对其它后代无影响 */
        .father > .son {
            color: coral;
        }

        /* 后代选择器 对后代所有元素产生影响 */
        .father p {
            font-family: SonTi;
            font-size: larger;
        }

        /* 相邻兄弟选择器 语法为 element1 + element2，选择紧接在 element1 之后的第一个 element2 元素，且它们必须有相同的父元素。 */
        h3 + p {
            background-color: darkgoldenrod;
        }

        /* 通用兄弟选择器 语法为 element1 ~ element2，选择 element1 之后的所有 element2 元素（无论是否紧邻），且它们必须有相同的父元素。*/
        h2 ~ p {
            background-color: darkgrey;
        }

        /* 伪类选择器 选择处于特定状态或位置的元素，无需修改 HTML 结构即可实现动态样式 */
        #element:hover {
            background-color: darksalmon;
        }
    </style>
</head>
<body>
    <h1>这是一个元素选择器</h1>
    <h2 class="highlight">这是一个类选择器</h2>
    <h3 id="header">这是一个 ID 选择器</h3>

    <div class="father">
        <p class="son">这是一个子元素选择器</p>
        <div>
            <p class="grandson">这是一个后代选择器</p>
        </div>
    </div>
    <hr>
    <div>
        <p>这是一个 p 标签</p>
        <h3>这是一个相邻兄弟选择器</h3>
        <p>这是另一个 p 标签</p> <!-- 这个p会被选中 -->
    </div>
    <hr>
    <div>
        <h2>这是一个通用兄弟选择器</h2>
        <p>这是一个 p 标签</p> <!-- 这个p会被选中 -->
        <p>这是另一个 p 标签</p> <!-- 这个p也会被选中 -->
    </div>
    <hr>
    <h3 id="element">这是一个伪类选择器</h3>
</body>
</html>
```

## CSS 常用属性

首先，弄清楚以下概念。块元素（block）、行内元素（inline）与行内块元素（inline-block）。

其中，block、inline-block可以设置width、height，inline不可以。且三者可以通过display属性互相转换。

如，要将行内元素 **span** 转换为行内块元素，可以使用如下 **CSS** 选择器：

```css
.span2inline-block {
    display: inline-block;
    background-color: blue;
    width: 200px;
}
```

设置字体，使用 **font** 属性，设置行高，使用 **line-height** 属性。

```html
<h1 style="font: bolder 50px 'KaiTi';">这是一个标题。</h1>
<p style="line-height: 40px;">这是一段长文本（省略...）</p>
```

## 盒子模型（Box Model）

| 属性名            | 说明                                       |
| ----------------- | ------------------------------------------ |
| 内容（Content）   | 盒子包含的实际内容，如文本、图片等         |
| 内边距（Padding） | 围绕在内容的内部，是内容与边框之间的空间。 |
| 边框（Border）    | 围绕在内边距的外部，是盒子的边界。         |
| 外边距（Margin）  | 围绕在边框的外部，是盒子与其他元素的空间。 |

```css
.border-demo {
    background-color: yellow;
    width: 300px;
    height: 200px;
    border-style: solid dashed dotted double; /* 按顺时针分配属性值 */
    border-width: 10px;
    border-color: blueviolet;
    padding: 50px;
    margin: 40px;
}
```

应用如上 **CSS** 格式，结果如下图所示（其中margin是该Box与其它文本的距离，图中未展示）。

<img src="C:\Users\pjj18\Desktop\note\前端\picture\boxEG.jpg" alt="boxEG" style="zoom:50%;" />

## 浮动与定位

### 传统网页布局方式

网页布局方式有以下五种：

- 标准流（普通流、文档流）：网页按照元素的书写顺序依次排序
- 浮动
- 定位
- `Flexbox` 和 `Grid` （自适应布局）

在开发中，通常是各种布局方式相结合。

### 浮动（float）

浮动属性用于创建浮动框，是相对于父元素浮动，只会在父元素内部移动。

```css
float: left | right | none | inline-start | inline-end;
```

最常用的是 `left` / `right` 。

浮动元素**不占正常高度**，父元素会出现“高度塌陷” → 需要**清除浮动**（clearfix）。

<img src="C:\Users\pjj18\Desktop\note\前端\picture\flowError.jpg" style="zoom:67%;" />

上图中，文本占据了块元素的空间，需要清除浮动。这里介绍两种方式。第一，在父元素中加入 `overflow: hidden;` 第二，或者使用伪元素选择器，如下。

```css
/* 在需要清除浮动的父元素上加这个类 */
.clearfix::after {
  content: "";      /* 必须存在，内容为空即可 */
  display: table;   /* 触发 block formatting context，防止 margin 塌陷 */
  clear: both;      /* 真正“清”掉左右浮动 */
}
```

<img src="C:\Users\pjj18\Desktop\note\前端\picture\flowClear.jpg" style="zoom: 40%;" />

```html
<!-- 以下是 style 中的内容-->
<style>
    .father {
        background-color: aquamarine;
        /* height: 150px; */
        border: 3px solid brown;
        /* overflow: hidden; */
    }	
    
    .father::after {
        content: "";
        display: table;
        clear: both;
    }
    
    .left-son {
        width: 100px;
        height: 100px;
        background-color: yellowgreen;
        float: left;
    }
    
    .right-son {
        width: 100px;
        height: 100px;
        background-color: yellow;
        float: right;
    }
</style>

<!-- 以下是 body 中的内容-->
<body>
    <div class="father">
        <div class="left-son">左浮动</div>
        <div class="right-son">右浮动</div>
    </div>
    <P>这是一段文本这是一段文本这是一段文本这是一段文本这是一段文本</P>
</body>
```

### 定位（position）

 定位包括 `相对定位relative、绝对定位absolute、固定定位fixed` 三种方式。

- **相对定位：**相对于元素在文档流中的正常位置进行定位。
- **绝对定位：**不占据文档流，相对于其最近的祖先元素进行定位。
- **固定定位：**相对于浏览器窗口定位。

三者的设置是利用 `position` 属性进行设置，使用 `left、right、top` 等进行设置。

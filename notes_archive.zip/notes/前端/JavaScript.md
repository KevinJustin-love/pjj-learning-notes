# JavaScript

`JavaScript` 应用领域包括但不限于 `客户端脚本、网页开发、后端开发` 。

## 导入方式

方式一： 使用 `script` 标签。在 `<head>/<body>` 部分中均可。

方式二： 使用外部的 `JS` 文件，按 `<script src="main.js"></script>` 格式导入（head、body中均可）。

```javascript
console.log('hello world!'); // 控制台打印
alert("hello world"); // 弹窗打印
```

注意，方式二要使用相对路径，使用绝对路径是无效的。

## 基本语法

### 变量声明

```js
var x; // 函数作用域，现代编程中应避免使用
let y = 5; // 块级作用域
const PI = 3.14; // 常量声明

let name = '如花';
let empty_value = null;
```

### 控制语句

与 `cpp` 完全一致，此处不赘述。

  ### 函数

有三种表述方式。

```js
// Function Declaration
function 函数名(参数1, 参数2, ...) {
  // 函数体
  return 返回值; // 可选
}
```

```js
// Function Expression
const 函数名 = function(参数1, 参数2, ...) {
  return 返回值;
};  // 注意分号
```

```js
// Arrow Function
const 函数名 = (参数1, 参数2) => {
  // 函数体
  return 返回值;
};  // 注意分号
```

### 事件

| 事件        | 描述         |
| ----------- | ------------ |
| onClick     | 点击事件     |
| onMouseOver | 鼠标经过     |
| onMouseOut  | 鼠标移出     |
| onChange    | 文本内容改变 |
| onSelect    | 文本框选中   |
| onFocus     | 光标聚集     |
| onBlur      | 移开光标     |

`JavaScript` 可以通过 `HTML、DOM、addEventListener` 三种方式绑定事件。

1. `HTML` 在 `<script>` 标签中定义函数，并将上述事件赋值给对应函数。

   ```html
   <button onclick="click_event()">
       这是一个点击事件按钮。
   </button>
   
   <script>
   	function click_event() 
       {
           alert('点击事件触发了');
       }
   </script>
   ```

2. `DOM`
   通过 ID、类、标签选择元素。

   ```html
   <div id="box1">这是一个 ID 选择器标签</div>
   <script>
   	var element_id = document.getElementById('box1');
       console.log(element_id);
       
       element_id.innerHTML = '修改选择器内容'; 
       // 也可以使用 innerText，但前者会解析如链接等，后者只传文本
       element_id.onmouseover = function()  // 使用匿名函数
       {
       	alert('警告！');
       }
   </script>
   ```

3. `addEventListener`
   上述事件 `onmouseover` 的触发等同如下。

   ```js
   element_id.addEventListener('onmouseover', function() {
       alert('警告！');
   })
   // 第一个变量是事件，第二个变量是触发结果。
   ```

   
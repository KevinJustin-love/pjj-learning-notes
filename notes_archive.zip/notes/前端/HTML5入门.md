# HTML入门 

`HTML: Hyper text Markup language（超文本标记语言）。`

HTML 通过标签来定义文本、图像、链接等。例如：

```html
<!-- 双标签 -->
<p> 这是一个段落。</p>
<h1> 这是一个标题。 </h1>
<a href="#"> 这是一个超链接。 </a>
<b> 黑体 </b>
<i> 斜体 </i>
<u> 下划线 </u>
<s> 删除线 </s>
```

```html
<!-- 单标签 br:换行 hr:水平分割线 -->
<input type="text">
<br>
<hr>
```

区别：单标签用于没有内容的元素，双标签用于有内容的元素

## HTML 文件结构

```html
<!DOCTYPE html>
<html>
    <head>
        <title>文档标题</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>
            这是一个标题。
        </h1>
        <p>
            这是一个段落。
        </p>
        <a href="https://www.bilibili.com/video/BV1BT4y1W7Aw?spm_id_from=333.788.videopod.episodes&vd_source=8d372b6a9cc7f61f68045441cb6490e4&p=3">这是一个链接</a>
        
    </body>
</html>
```

## 列表&表格

```html
<!-- unordered list -->
<ul>
    <li>无序列表元素1</li>
    <li>无序列表元素2</li>
    <li>无序列表元素3</li>
</ul>

<!-- ordered list -->
<ol>
    <li>有序列表元素1</li>
    <li>有序列表元素2</li>
    <li>有序列表元素3</li>
</ol>

<!-- table 
tr-- table row
th-- table headed
td-- table data
border-- 表格边框, 数字表示边框宽度
-->
<table border="1">
    <tr>
        <th>title1</th>
        <th>title2</th>
        <th>title3</th>
    </tr>
    <tr>
        <td>data1</td>
        <td>data2</td>
        <td>data3</td>
    </tr>
    <tr>
        <td>data11</td>
        <td>data12</td>
        <td>data13</td>
    </tr>
</table>
```

## HTML 标签属性

`属性定义元素的行为和外观，以及与其他元素的关系`

基本语法：`<开始标签 属性名="属性值">`    其中，属性名不区分大小写，属性值区分大小写。

```html
<p id="describe" class="section">这是一个段落标签</p>
<a href="url" target="_blank">这是一个超链接</a> <!-- target 有四个属性，分别对应不同的页面打开方式 -->
<img src="path/url" alt="这里是图片无法加载时的替代文本" width="" height=""> 
```

上述 table 的 border 也是一个属性。

**适用于大多数 HTML 元素的属性：**

| 属性  |           描述            |
| :---: | :-----------------------: |
| class | 为 HTML指定一个或多个类名 |
|  id   |     定义元素唯一的 id     |
| style |    规定元素的行内样式     |

这些属性将主要应用于 **CSS** 。

## HTML 区块

HTML 区块主要分为块元素和行内元素。

### 块元素（block）

`用于组织和布局页面的主要结构和内容。将内容分为逻辑块。`

+ 块级元素通常会从新行开启，并占据整行的宽度，因此它们会在页面上呈现为一块独立的内容块。
+ 可以包含其它块级元素和行内元素。
+ 常见的块级元素包括 `<div> <p> <h1> ~ <h6> <ul> <ol> <li> <table> <form>` 等。

### 行内元素（inline）

`用于添加文本样式或为文本中的一部分应用样式。可以在文本中插入小的元素，如超链接、强调文本等。`

+ 行内元素通常在同一行呈现，不会独占一行。
+ 行内元素不能包括块级元素，但能包括其它行内元素。
+ 常见的行内元素包括`<span> <a> <strong> <em> <img> <br> <input>` 等。

+++

### div、span 标签

`div` 标签，将内容分为不同的区域。

```html
<!-- 
nav: navigator 导航
content: 内容

-->
<div class="nav">
    <a href="#">链接 1</a>
    <a href="#">链接 2</a>
    <a href="#">链接 3</a>
</div>

<div class="content">
    <h1>标题</h1>
    <p>内容</p>
    <p>内容</p>
    <p>内容</p>
    <p>内容</p>
    <p>内容</p>
</div>
```

`.nav` 得到 `<div class="nav"></div>` 

`#nav` 得到 `<div id="nav"></div>`

+++

`span` 标签，将部分文本包裹，以便对这部分进行各种操作。

```html
<span>这是一个 span 标签</span>
<span>链接点击这里 <a href="#">链接</a></span>
```

## HTML 表单

`表单（Form）`是 HTML 中用于收集用户输入的一种机制。它允许用户通过输入框、选择框、按钮等控件输入数据，并将这些数据发送到服务器进行处理。

```html
<form>
    <label>用户名：</label>                                 <!-- 此处可用span替代label -->
    <input type="text" value="请输入内容"> <br> <br>        <!-- 注：辨析value、placeholder -->
    <label for="pwd">密码：</label>                        
    <input type="password" id="pwd" placeholder="请输入内容"> <br> <br>  
    
    <label>性别</label>
    <input type="radio" name="gender"> 男
    <input type="radio" name="gender"> 女
    <input type="radio" name="gender"> 其他 <br> <br>      <!-- 定义三者name相同，确保用户只能三选一 -->  
    
    <label>爱好</label>
    <input type="checkbox" name="hobby"> 唱
    <input type="checkbox" name="hobby"> 跳
    <input type="checkbox" name="hobby"> rap
    <input type="checkbox" name="hobby"> 篮球              <!-- checkbox可多选，即使name相同 -->
    <br> <br>
    <input type="submit">
</form>

<form action="#"><form>                                    <!-- action的值为表单结果提交到的url链接 -->
```

上述代码的结果如下所示。

<img src="C:\Users\pjj18\Desktop\note\前端\picture\html.jpg" alt="html" style="zoom:60%;" />




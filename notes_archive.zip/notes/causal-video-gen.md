# AR Video Gen

:date: 08/19/2026

:writing_hand: Kevin Justin

## Overall Paradigm

得到高质量 AR 主要有三种范式：

1. 强 bi-directional teacher -> casualize -> self-forcing + DMD
2. from-scratch train，自回归的 di model
3. next-scale AR (代表：InfinityStar)

这里需要注意，AR video model 有两种含义：

- 一种是把视频分为 frame/chunk，数学表达是 $$p(x_{1:C}\mid y)
  =
  \prod_{c=1}^{C}
  p_\theta(x_c\mid x_{<c},y).$$ 每一个 $p_\theta(x_c\mid x_{<c},y)$ 是 conditional diffusion/flow model
- 另一种是 next-scale AR，数学表达是 $p(r\mid y)
  =
  \prod_c\prod_k
  p_\theta
  \left(
  r_{c,k}
  \mid
  r_{<c,*},r_{c,<k},y
  \right).$ 其中
  - c 是 temporal clip
  - k 是 spatial clip 
  - $r_{c,k}$ 是一个离散 residual token block 

### 补充：Infinity & VAR

**VAR**

对于范式 3，其基于图像的一个叫做 Infinity 的工作，Infinity 又基于 VAR。

VAR 的方法可以简单理解为把图像编码为多个 scale，$r_1,r_2,\ldots,r_K,$  如

$1\times1
\rightarrow
2\times2
\rightarrow
4\times4
\rightarrow
8\times8
\rightarrow
16\times16.$

然后 factorization 变成 $$\boxed{
p(r_1,\ldots,r_K)
=
\prod_{k=1}^{K}
p(r_k|r_{<k})
}$$

称之为 next-scale prediction (同一 scale 不是 ar)

> 注：VAR 生图会训练一个专门的 multi-scale VQ(Vector Quantization) AE，最终的 continuous feature 由多个 scale 的特征叠加得到，为一个 coarse-to-fine 的过程

**Infinity**

主要修改 VAR 的 visual tokenizer，解决 VQ codebook 可能过大的问题。将预测的 token ID 改为 bits(即用二进制表示)，复杂度从 $O(2^d)$ 近似为 $O(d)$

另外一个创新点是，从 VAR 类似 teacher forcing 的方法改为了 self forcing 方法

## 路线1：bi-directional teacher 中蒸馏得到

| 方法                 | 核心 recipe                                                  | 它主要修复什么                                        |
| -------------------- | ------------------------------------------------------------ | ----------------------------------------------------- |
| **CausVid**          | bidir teacher → ODE initialization → causal 4-step student → asymmetric DMD | 50-step → 4-step、bidir → causal                      |
| **Self-Forcing**     | 在 student 自己生成的 history 上 rollout，再做 video-level DMD | exposure bias                                         |
| **Causal Forcing**   | 先训练 causal diffusion teacher，再从 causal teacher 做 ODE distillation | bidir teacher → causal student 的 structural mismatch |
| **Causal Forcing++** | causal consistency distillation 代替完整 ODE trajectory      | 1–2 step 初始化成本                                   |
| **Causal-rCM**       | $\boxed{\text{TF}\rightarrow\text{TF-CM}\rightarrow\text{SF-DMD}}$  学会 AR -> 加速 AR -> 解决 exposure bias | mode coverage + on-policy quality                     |
| **CMD**              | causal teacher + causal DMD scoring + Prefix Scoring         | 消除 DMD teacher 偷看未来的问题                       |

关键词解释：

- TF：Teacher Forcing，问题是 exposure bias
- TF-CM：Teacher-Forcing Consistency Model. Many-step causal diffusion -> Few-step
- SF：Self-forcing
- DMD：Distribution Matching Distillation
